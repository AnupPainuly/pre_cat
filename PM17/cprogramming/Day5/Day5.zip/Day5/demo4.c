// count no of digts
// 123  == 3 digits
// 99   == 2 digits
// 12345 == 5 digits
// -123 ==  3 digits
// -99 ==  3 digits

/*
1. start
2. accept no
3. assign counter =0
4. check no!=0
        if yes
           divied no by 10 and store in no
           increment counter by 1
        goto step 4
5. if false 
      print counter
6, stop


// dry run
 no    counter 
123/10      0+1=1
12/10       1+1=2
1/10        2+1=3
0
no of digits=3 counter

no    counter
-95/10    0  + 1=1
-9/10     1+1=2
0

-95 is 2 digits
*/
#include<stdio.h>
int main(void)
{
    int no, counter;

    printf("\n Enter No ::");
    scanf("%d", &no);
    if(no==0)
        printf("\n no of digits= 1" );
    else
    {
        counter=0;
        while(no!=0)
        {   
            no/=10; // no=no/10;  short hand op
            counter++; // counter= counter+1;
        }
        printf("\n no of digits=%d", counter);
    }
    return 0;
}







