#include<stdio.h>
int main(void)
{
    int no;  // print 65 to 122
    for(no=65; no<=122; no++)
    {
        printf("\n %c %d", no, no);
    }
    return 0;
}