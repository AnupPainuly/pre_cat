// menu driven prog (simple calculator)
#include<stdio.h> 
typedef enum menuchoice
{
  Exit, Add, Minus, Multiply=3, Divide 
  // 0   1    2        3          4
}MENUCHOICE;
//typedef enum menuchocie MENUCHOICE;
int main(void)
{
    int no1, no2, ans;
    MENUCHOICE choice;//enum menuchoice choice;

    do
    {
        printf("\n Enter No1 :: ");
        scanf("%d", &no1);
        printf("\n Enter No2 :: ");
        scanf("%d", &no2);

        printf("\n Enter Your choice :: ");
        printf("\n 1. Add \n 2. Minus \n 3. Multiply \n 4 Divide \n 0. Exit:: ");
        scanf("%d", &choice);

        switch(choice) 
        {
            case Add: // Add=1
                        ans= no1+no2; break;
            case Minus: // Minus=2
                        ans= no1-no2; break;
            case Multiply: // Multiply=3
                        ans= no1*no2; break;
            case Divide: // Divide=3
                        ans= no1/no2; break;        
        }
        printf("\n ans=%d", ans);

        printf("\n Enter 1 to continue or 0 to exit ");
        scanf("%d", &choice);
        
    } while (choice!=0);


    return 0;

}

/*
// if condition in while and for false then it will go out of loop
do while loop will execute at least once
for menu driven prog condition we should use do while loop

init;  //1
do //2
{ //3 
    statement1;
    statement2; //4
    incre/decre;  //5
}while(condition);//6
//7

1  2 3 4 5 6 if condition is true
     3 4 5 6 if condition is true
     3 4 5 6 if condition is false
     7

*/




