// example of addition of 2 numbers using function
// 1. function decl 
// 2. function defination
// 3. function calls

// 1  function decl (proto type of function)
//output function_name(input)
//return_type function_name(data_type parametername)
int addition(int n1, int n2);
int main(void)
{
    int no1, no2, ans;

    printf("\n Enter no1::");
    scanf("%d", &no1);
    printf("\n Enter no2::");
    scanf("%d", &no2);

    ans=0;
    ans=addition(no1, no2); //3. function call
    // no1 , no2 is actual argruments
    printf("\n %d + %d = %d", no1, no2, ans);
    return 0;
}
// 2. function defination is impelmentation of function (logic)
// n1, n2 is formal arguments
int addition(int n1, int n2)
{
    int temp=0;
    temp= n1+n2;
    return temp;
}

// return 10;   int
// return 'A';   char
// return 10.2;   double
// return 10.2f;   float
// return 10.2F;   float
// return;         void
// return 10,20;   return 20;
// return (10,20);   return 20;
// return "sunbeam"    ??