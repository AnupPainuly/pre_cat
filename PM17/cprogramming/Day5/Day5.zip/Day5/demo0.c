// enum
// typedef 
// function call by value
// nested loops
// sum of digits
// factorial
// count no of digits
// rev digits
// sum of 1st n numbers
// 5 --> 1 +2+3+4+5=15
