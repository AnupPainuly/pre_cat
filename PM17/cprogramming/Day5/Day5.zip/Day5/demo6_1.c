#include<stdio.h>
int main(void)
{
    int no;  // print 65 to 122 dont print 91 to 96 using (!) not operator
    for(no=65; no<=122; no++)
    {
        if(!(no>=91 && no<=96))
            printf("\n %c %d", no, no);
    }
    return 0;
}