/* sum of digits
   123 == 1+2+3== 6  
   95  == 9+5=   14
   12345== 1+2+3+4+5== 15

   1. start
   2. accept no
   3. assign sum=rem=0
   4. check no!=0
        if yes
            rem= no%10;
            divide no bu 10 and store in no
            add rem into sum
        go to step 4
    5. if no
      print sum
    6. stop

   no  rem   sum
123%10  0     0+3
123/10  3      3
12%10   2     3+2=5
12/10  
1%10     1    5+1=6 
1/10
0

-95%10    0      0
-95/10    -5     0+ -5= =-5
-9%10     -9     -5-9= -14
-9/10     
0
*/

#include<stdio.h>
int main(void)
{
    int no1, rem, sum;
    printf("\n Enter No ::");
    scanf("%d", &no1);

    rem= sum=0;
    while(no1!=0)
    {
        rem= no1%10;
        no1/=10;   // no1= no1/10;
        sum+=rem;  // sum= sum+rem;
    }
    printf("\n sum of digit =%d", sum);

    return 0;
}





