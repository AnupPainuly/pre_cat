
#include<stdio.h>
int main(void)
{
    int no1, rem, sum;
    printf("\n Enter No ::");
    scanf("%d", &no1);

   
    for( rem= sum=0; no1!=0;no1/=10)
    {
        rem= no1%10;
        sum+=rem;  // sum= sum+rem;
    }
    printf("\n sum of digit =%d", sum);

    return 0;
}


/*
1. palindrome
if u rev no it will get orignal no then it is palindrome

121  ==  121
222  ==  222
333  ==  333

123 == 321   not
122 == 221   not

2. armstrong
sum of the cube of digit equal to orignal no

153 == 1*1*1 + 5*5*5 + 3*3*3
    ==  1 +125 +27
    ==  153

1     153   370  371    407


perfect no
sum of factors excluding or no equal to no

6 = 1+2+3 == 6 prefect no
28= 1+2+4+7+14= 28  perfect no

*/


