#include<stdio.h>
// decl of enum // logical entity blue print for home 
enum month
{  // member of enum
    Exit,Jan=1,  Feb,   Mar,  Apr
    //0  0+1=1 1+1=2  2+1=3 3+1=4 
};
int main(void)
{// data type variable of int data type
         int no1;
   //enum month is user define data type (logical entity)
   // m is variable of use defined data type enum momth ( m is physical entity)
   // enum is int constant - 4 bytes 
    enum month m;

    printf("\n Enter Month :: ");
    scanf("%d", &no1); // way2 scaning int and assign to enum after type casting

    // way3 scaning int assigned using switch case
    switch(no1)
    {
        default: m=-1; break;
        case 0: return 0;
        case 1: m=Jan; break;
        case 2: m=Feb; break;
        case 3: m=Mar; break;
        case 4: m=Apr; break;
    }

    switch (m)
    {
        case Jan: printf("\n Jan has 31 days"); break;
        case Feb: printf("\n Feb has 29/28 days"); break;
        case Mar: printf("\n Mar has 31 days"); break;
        case Apr: printf("\n Apr has 30 days"); break;
    }

    printf("\n sizeof (enum month)=%d", sizeof(enum month)); // 4 bytes
    printf("\n sizeof (m)=%d", sizeof(m)); // 4 bytes

    return 0;
}
