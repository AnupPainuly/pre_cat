#include<stdio.h>
int main(void)
{
    int no;  // print 65 to 122 dont print 91 to 96 using break
    for(no=65; no<=122; no++)
    {
        if((no>=91 && no<=96))
        {}
        else
            printf("\n %d %c", no, no);
    }

    //print 65 to 90  dont print any thing after 91
    return 0;
}