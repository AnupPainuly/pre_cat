#include<stdio.h>
int main(void)
{
    int z=3;         // variable
    //int *z_ptr=&z;   // pointer init at time decl
    // or
    int *z_ptr=NULL;  // decl of pointer
    z_ptr= &z;                           
                                          //3  *(1000)==3  *(1000)==3
    printf("\n z=%d  *(&z)=%d   *z_ptr=%d", z, *(&z),     *z_ptr);
    printf("\n  &z=%u z_ptr=%u  &z_ptr=%u", &z, z_ptr, &z_ptr);
    printf("\n  &z=%p z_ptr=%p  &z_ptr=%p", &z, z_ptr, &z_ptr);


    *z_ptr=5;                             // 5   5          5
    printf("\n z=%d  *(&z)=%d   *z_ptr=%d", z, *(&z),     *z_ptr);
    printf("\n  &z=%u z_ptr=%u  &z_ptr=%u", &z, z_ptr, &z_ptr);

    printf("\n size of z_ptr =%d", sizeof(z_ptr));

    return 0;
}  // gcc -m32 demo6.c     32 bit
 // gcc -m64 demo6.c     64 bit


//64 bit operaing system/compilation size of any data type pointer is 8 bytes
//32 bit operaing system/compilation size of any data type pointer is 4 bytes
// turboc3 -- dos  -- 16 bit 
//16 bit operaing system/compilation size of any data type pointer is 2 bytes
// types of pointer on turboc
//  near (2 bytes) , far and huge 4 bytes


