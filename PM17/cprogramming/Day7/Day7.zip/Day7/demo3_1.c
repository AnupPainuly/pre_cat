#include<stdio.h>
extern int no1;  // decl of global variable
int main()
{
    int no1=50;  // local variable
    printf("\n local from main no1= %d &no1=%u", no1, &no1); //50 local
    { // block1
        int no1=100; // decl and defination of local variable
        printf("\n in block1  no1= %d &no1=%u", no1, &no1); //100 local to block
        { // block2
           int no1=500; 
            printf("\n in block2  no1= %d &no1=%u", no1, &no1); //500 local to block
    }
    }
    return 0;
}
int no1=10; // defination of global variable
