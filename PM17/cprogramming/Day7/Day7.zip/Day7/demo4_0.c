#include<stdio.h>
void fun()
{
    int no1=1;
    if(no1>10)
        return;
    else
    {
        printf("\n no1= %d [%u] ", no1, &no1);
        no1++;
    }
    fun();
}  // print 1 till stack overflow
int main(void)
{
    fun();   
    return 0;
}