#include<stdio.h>
void fun1()
{
    int  no1=10, no2=20, no3=30; // local var
    static int  a=11, b=22, c=33; // static var

    no1++; no2++, no3++;
    a++; b++; c++;
    printf("\n no1=%d no2=%d no3=%d", no1, no2, no3);
    printf("\n &no1=%u &no2=%u &no3=%u", &no1, &no2, &no3);
    printf("\n a=%d b=%d c=%d", a, b, c);
    printf("\n &a=%u &b=%u &c=%u", &a, &b, &c);
    return;
}
int main()
{
     fun1();    // no1=11, no2=21 , no3=31
                // a=12    b=23    c=34

    fun1();    // no1=11, no2=21 , no3=31
                // a=13    b=24    c=35
    fun1();    // no1=11, no2=21 , no3=31
                // a=14    b=25    c=36

    return 0;
}

