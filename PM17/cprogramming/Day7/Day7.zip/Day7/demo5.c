#include<stdio.h>
int no1=1;
int main(void)
{
   if(no1>10)
        return;
    else
    {
        printf("\n no1= %d [%u] ", no1, &no1);
        no1++;
    }
    main();  
    return 0;
}