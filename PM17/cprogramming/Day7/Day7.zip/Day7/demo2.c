#include<stdio.h>
 //   register int no2=10;

int main(void)
{
    register int no1=10;

    printf("\n Enter No1=");
    //scanf("%d", &no1);  error
     //error: address of register variable ‘no1’ requested

    printf("\n no1=%d", no1);
    no1=100;
    printf("\n no1=%d", no1);
    return 0;
}