#include<stdio.h>
int no1=10; // defination of global variable
int main()
{
    printf("\n global var no1=%d [%u]", no1, &no1);
    return 0;
}

