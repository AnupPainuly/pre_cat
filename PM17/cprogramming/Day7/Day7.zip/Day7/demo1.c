#include<stdio.h>
int fact(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No :: ");
    scanf("%d", &no);

    ans= fact(no);// actual arg
    printf("\n %d! =%d",no, ans);
    return 0;
}
int fact(int n) // n is formal arg
{
    int f=1;

    printf("\n n=%d [%u] cnt=%d", n, &n);
    if(n==1)  // ternmination condition
    {
        f=1;
        printf("\n fact(%d) f=%d ", n, f);
        return 1;
    }
    else
    {
       // f= n * fact(n-1);
       f= n * fact(n--);
         //f= n * fact(--n);
        printf("\n fact(%d) f=%d", n, f);
    }
    return f;
}