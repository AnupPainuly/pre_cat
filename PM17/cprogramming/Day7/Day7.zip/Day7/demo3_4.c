#include<stdio.h>
int no1=10; // defination of global variable
int main()
{
    printf("\n global var no1=%d [%u]", no1, &no1);
    return 0;
}
extern int no1;  // decl of global variable
