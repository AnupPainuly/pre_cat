#include<stdio.h>
extern int no1; // decl of global variable
int main()
{
    printf("\n global var no1=%d [%u]", no1, &no1);
    return 0;
}
// undefined reference to `no1' linking error