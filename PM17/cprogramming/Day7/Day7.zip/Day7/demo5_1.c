#include<stdio.h>

int main(void)
{
    static int no1=1;
   if(no1>10)
        return;
    else
    {
        printf("\n no1= %d [%u] ", no1, &no1);
        no1++;
    }
    main();  
    return 0;
}