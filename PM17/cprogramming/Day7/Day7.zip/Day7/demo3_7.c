#include<stdio.h>
int main()
{
    int no2=100;
    //static int no1=no2;  // not allowed //error

    static int no3=100;  // allowed
    static int no4;  // allowed  default value zero

    printf("\n no3=%d", no3);
    no3=no2; // assigment allowed
    printf("\n no3=%d", no3);
    return 0;
}