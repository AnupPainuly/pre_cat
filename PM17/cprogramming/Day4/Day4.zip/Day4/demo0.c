// char is vov or con
// no of  days in month
// if swicth with months
// loops - while , for, do while
// enum
// typedef
// semicolon and comma
// unsigned int checked with if

