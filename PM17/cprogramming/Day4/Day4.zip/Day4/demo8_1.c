#include<stdio.h>
int main(void)
{
    int no1=5, no2=0;
    if(no1, no2, no1) // if (5, 0, 5) non zero true
        printf("\n yes");  // print yes
    else
        printf("\n no");
    return 0;
}