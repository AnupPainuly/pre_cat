#include<stdio.h>
int main(void)
{
    int no1=5, no2=0;
    if(no1, no2) // if (5, 0)  zero false
        printf("\n yes"); 
    else
        printf("\n no"); // print no
    return 0;
}