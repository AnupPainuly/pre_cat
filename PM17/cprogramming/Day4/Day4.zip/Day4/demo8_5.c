#include<stdio.h>
int main(void)
{
    int no1=5;
    if(no1) // if(5)  non zero true
        printf("\n yes"); // print yes
    else;
        printf("\n no"); // print no
    return 0;
} // print both yes and no