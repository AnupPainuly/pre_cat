// array and pointer noatation
// passing array to fun
     // read write sum , max , max min , avg
// diff macro and functions
// sum prod div error message
// string and array of char
// scan sets


// constant combination with pointers
// void pointer
// twisters on array
