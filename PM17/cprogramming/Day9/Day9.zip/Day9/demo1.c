#include <stdio.h>
int main(void)
{
    int a    = 1;
    int *p = &a;
    int *q = p;
    *p = *p + *q;

    printf("%d %d %d",*p   , a,*q);
                    //*(100) 2 *(100) 
                    //  2    2   2
    return 0;
}