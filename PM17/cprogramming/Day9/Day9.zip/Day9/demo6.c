// scan sets
#include<stdio.h>  
#include<string.h>  
#define LEN 40
int main(void)
{
    // string
    char city[LEN];

    printf("\n Enter city ::");
    //scanf("%s", city); // new delhi
    // scan upto 1st space (word)

    //gets(city); // it will scan upto \n new line char line
    //scanf("%[^\n]s", city); // line
    //scanf("%[^.]s", city);
    // it will scanf upto . char
    scanf("%[^*]s", city);
    // it will scanf upto * char
    // it will scan upto \n new line char
    printf("\n city=%s", city);

    return 0;
}

/*
Meeting ID: 540 342 2999
Passcode: sunbeam
*/




