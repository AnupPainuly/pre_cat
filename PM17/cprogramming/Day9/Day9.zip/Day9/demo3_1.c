#include<stdio.h>
#define SIZE 5
//void accept_array(int a[SIZE], int size); 
void accept_array(int a[], int size); // fun decl
void print_array(int *a, int size); 
int array_sum(int *a, int size);
int main(void)
{
    int arr [SIZE] ,ans=0;
    
    // accept array scanf
    printf("\n enter Elements of array \n");
    accept_array(arr, SIZE); // fun call

    // display array printf
    printf("\n Elements of array \n");
    print_array(arr, SIZE);

    //arr++;  error  arr is an array
    printf("\n size of arr =%d", sizeof(arr)); // SIZE*4 == 5*4=20
    
    ans= array_sum(arr, SIZE);
    printf("\n sum of array = %d", ans);
    return 0;
}
void accept_array(int a[], int size)  // fun defination
{
    int index;
    for(index=0; index< size; index++)
    {
        printf("\n arr[%d] =", index);
        //scanf("%d", &a[index]);  // array notation
        //  scanf("%d", &index[a]);  
        //scanf("%d", (a+index));  // pointer notation
          scanf("%d", (index+a));  
    }
    return;  
}
void print_array(int *a, int size)
{
    int index;
    for(index=0; index<SIZE; index++)
    {  
        // array notation
        // printf("\n a[%d] %d [%u]",index, a[index], &a[index]);
        //   printf("\n %d[a] %d [%u]",index, index[a], &index[a]);
        // pointer notation
        //printf("\n *(a+%d) %d [%u]",index, *(a+index), (a+index));
          printf("\n *(%d+a) %d [%u]",index, *(index+a), (index+a));        
    }
    return;
}
int array_sum(int *a, int size)
{
    int sum, index;
    for(index=sum=0; index<size; index++)
    {
        sum+= a[index];//sum= sum+ *(a+index);       
    }   
    return sum;
}