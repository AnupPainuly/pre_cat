#include<stdio.h>  
#include<string.h>  
#define LEN 40
int main(void)
{
    // string
    char city1[LEN]="pune"; // compiler will add '\0'
    char city2[]={'p','u', 'n','e', '\0'}; // we have to add '\0' at end
    char city3[LEN]={'k','a', 'r','a','d', '\0'}; // we have to add '\0' at end
    char city4[]="karad"; // compiler will add '\0'

    // array of char
    char city5[]={'p','u', 'n','e'}; 
    
    printf("\n size of %s is %d", city1,sizeof(city1)); // 40
    printf("\n length of %s is %d", city1,strlen(city1)); //4

    printf("\n size of %s is %d", city2,sizeof(city2));//5
    printf("\n length of %s is %d", city2,strlen(city2));//4

    printf("\n size of %s is %d", city3,sizeof(city3));//40
    printf("\n length of %s is %d", city3,strlen(city3));//5
    
    printf("\n size of %s is %d", city4,sizeof(city4));//6
    printf("\n length of %s is %d", city4,strlen(city4));//5

    return 0;
}