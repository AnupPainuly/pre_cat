#include<stdio.h>
#define SIZE 5
int main(void)
{
    int arr [SIZE] ;
    int index;
    // accept array scanf
    printf("\n enter Elements of array \n");
    for(index=0; index< SIZE; index++)
    {
        printf("\n arr[%d] =", index);
        //scanf("%d", &arr[index]);  // array notation
        //  scanf("%d", &index[arr]);  
        //scanf("%d", (arr+index));  // pointer notation
          scanf("%d", (index+arr));  
    }
    // display array printf
    printf("\n Elements of array \n");
    for(index=0; index<SIZE; index++)
    {  
        // array notation
        // printf("\n arr[%d] %d [%u]",index, arr[index], &arr[index]);
        //   printf("\n %d[arr] %d [%u]",index, index[arr], &index[arr]);
        // pointer notation
        //printf("\n *(arr+%d) %d [%u]",index, *(arr+index), (arr+index));
          printf("\n *(%d+arr) %d [%u]",index, *(index+arr), (index+arr));
        
    }

    
    return 0;
}

/*
 int  *ptr=NULL;  // sizeof(ptr)=4 or 8 bytes
 int arr[5];     // 5*4=20

 ptr++, ++ptr, --ptr, ptr--  // allowed
 arr++, ++arr, --arr, arr--  // not allowed lvalue req error
 */