#include<stdio.h>
int main(void)
{
    printf("\n \\a =%d", '\a'); //7
    printf("\n \\b =%d", '\b'); //8
    printf("\n \\t =%d", '\t'); //9
    printf("\n \\n =%d", '\n'); //10
    printf("\n \\r =%d", '\r'); //13
    return 0;
}