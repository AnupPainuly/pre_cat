#include<stdio.h>
int main(void)
{
    char ch1;
    printf("\n Enterch1=");
    scanf("%c", &ch1);
    
    printf("\n ch=%c ch=%d",ch1, ch1);
            // char  ascii value
    return 0;
}
