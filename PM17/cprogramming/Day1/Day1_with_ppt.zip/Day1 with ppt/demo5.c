#include<stdio.h>
int main(void)
{
    int no1, no2;
    printf("\n Enter No1=");
    scanf("%d", &no1);
    printf("\n Enter No2=");
    scanf("%d", &no2);
    
    printf("\n no1=%d no2=%d", no1, no2);
    return 0;
}