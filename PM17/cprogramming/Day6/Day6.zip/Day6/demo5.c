/*
5! == 5*4!
        4*3!
          3*2! 
            2*1!


n!=  n * (n-1)!   rec for
till n==1    termination condotion


power =  2^5 =  2* 2^4
                     2*2^3
                       2*2^2
                          2*2^1
                            2*2^0

power=  base * (base, index-1)   rec formula
till index==0



sum of n numbers

sum=  5 + 4
          4+ 3
             3+2
               2+1


sum =  n+ (n-1) rec formula
till n==1


*/

#include<stdio.h>
int sum(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No :: ");
    scanf("%d", &no);

    ans= sum(no);
    printf("\n sum =%d", ans);
    return 0;
}
int sum(int n)
{
    int add=0;
    if(n==1)  // ternmination condition
    {
        add=1;
        printf("\n sum(%d) add=%d", n, add);
        return 1;
    }
    else
    {
        add= n + sum(n-1);
        printf("\nsum(%d) add=%d", n, add);
    }
    return add;
}
/*
int sum(int n)
{
    if(n==1)  // ternmination condition
        return 1;
    else
        return n+ sum(n-1);
}*/