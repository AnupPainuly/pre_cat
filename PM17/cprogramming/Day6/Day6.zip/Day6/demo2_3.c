#include<stdio.h>
int factorial(int n); // fun decl
int is_strong(int n); // fun decl
void strong_no_in_range(int lower,int upper); // fun decl
int main(void)
{
    int lower_lim,upper_lim ;

    printf("\n Enter lower lim :: ");
    scanf("%d", &lower_lim);

    printf("\n Enter upper lim :: ");
    scanf("%d", &upper_lim);

    printf("\n strong between %d to %d", lower_lim, upper_lim);
    strong_no_in_range(lower_lim, upper_lim);

    return 0;
}
// fun defination
int factorial(int n) 
{
    int fact, counter;
    for(counter=fact=1; counter<=n; counter++)   
    {
       // printf("%5d*", counter);
        fact*=counter;//fact= fact*counter;
    }
    //printf("\b ");
    return fact;      
}
int is_strong(int n)
{
    int  sum, rem;
    sum=rem=0;
    while(n!=0)
    {
        rem= n%10;
        n/=10 ;  // n= n/10;
        sum+=factorial(rem);
    }
    return sum;
}
void strong_no_in_range(int lower,int upper)
{
    int no;
    for(no=lower; no<=upper; no++)      
    {
        if(no== is_strong(no))
            printf("\n%5d", no);
    }
    return;
}