// 1 to 100 numbers
#include<stdio.h>
int main(void)
{
    int row, col;
    for(row=1; row<=10; row++)
    {
        for(col=1; col<=10; col++)
        {
            printf("%5d", row + (col-1)*10);
        }
        printf("\n"); // go to next row
        
    }
    return 0;
} // 1 to 1000 numbers  