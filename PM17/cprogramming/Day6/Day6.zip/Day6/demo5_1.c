#include<stdio.h>
int fact(int n);
int main(void)
{
    int no, ans;
    printf("\n Enter No :: ");
    scanf("%d", &no);

    ans= fact(no);
    printf("\n %d! =%d",no, ans);
    return 0;
}
int fact(int n)
{
    int add=1;
    if(n==1)  // ternmination condition
    {
        add=1;
        printf("\n fact(%d) add=%d", n, add);
        return 1;
    }
    else
    {
        add= n * fact(n-1);
        printf("\n fact(%d) add=%d", n, add);
    }
    return add;
}