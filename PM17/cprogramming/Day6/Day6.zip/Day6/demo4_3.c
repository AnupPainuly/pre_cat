// 1 to 100 numbers
#include<stdio.h>
int main(void)
{
    int row, col, no, cnt=1;
    printf("\n enter how many rows u want :: ");
    scanf("%d", &no);
    for(row=1; row<=no; row++)
    {
        for(col=1; col<=row; col++)
        {
           // printf("%5d", row);
           // printf("%5d", col);
           // printf("%2c", row+64);
           // printf("%2c", col+64);
           // printf(" * ");
           printf("%3d", cnt++);
        }
        printf("\n"); // go to next row
        
    }
    return 0;
} 