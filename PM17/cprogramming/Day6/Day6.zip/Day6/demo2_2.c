#include<stdio.h>
int factorial(int n); // fun decl
int is_strong(int n); // fun decl
int main(void)
{
    int no, ans;

    printf("\n Enter No :: ");
    scanf("%d", &no);

    ans=0;
    ans= is_strong(no); // fun call
    if(ans== no)
        printf("\n %d is strong no", no);
    else
        printf("\n %d is not strong no", no);

    return 0;
}
// fun defination
int factorial(int n) 
{
    int fact, counter;
    for(counter=fact=1; counter<=n; counter++)   
    {
       // printf("%5d*", counter);
        fact*=counter;//fact= fact*counter;
    }
    //printf("\b ");
    return fact;      
}
int is_strong(int n)
{
    int  sum, rem;
    sum=rem=0;
    while(n!=0)
    {
        rem= n%10;
        n/=10 ;  // n= n/10;
        sum+=factorial(rem);
    }
    return sum;
}