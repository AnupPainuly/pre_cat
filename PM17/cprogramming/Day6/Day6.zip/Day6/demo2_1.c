#include<stdio.h>
int factorial(int n); // fun decl
int main(void)
{
    int no, ans;

    printf("\n Enter No :: ");
    scanf("%d", &no);

    ans=0;
    ans= factorial(no); // fun call
    printf("\n %d!= %d", no, ans);

    return 0;
}
// fun defination
int factorial(int n) 
{
    int fact, counter;
    for(counter=n, fact=1; counter>=1; counter--)   
    {
        printf("%5d*", counter);
        fact*=counter;//fact= fact*counter;
    }
    printf("\b ");
    return fact;      
}
/*
    n     counter  fact
    5       1+1=2  1*1=1
            2+1=3  1*2=2
            3+1=4  2*3=6
            4+1=5  6*4=24
            5+1=6 false  24*5=120
*/


