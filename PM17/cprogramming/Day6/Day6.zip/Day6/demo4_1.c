// nested loops  table of no hori vertical
#include<stdio.h>
int main(void)
{
    int row, col;
    for(row=1; row<=10; row++)
    {
        for(col=1; col<=10; col++)
        {
            printf("%5d", row* col);
        }
        printf("\n"); // go to next row
        
    }
    return 0;
}