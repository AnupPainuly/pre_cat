// nested loops
#include<stdio.h>
int main(void)
{
    int row, col;
    for(row=1; row<=10; row++)
    {
        for(col=1; col<=10; col++)
        {
            printf("\n row=%d col=%d", row, col);
        }
        printf("\n"); // go to next row
        getchar();
    }
    return 0;
}