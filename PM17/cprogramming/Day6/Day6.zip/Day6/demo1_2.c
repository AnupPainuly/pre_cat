#include<stdio.h>
//float addition(float n1, float n2); // global decl
float addition(float n1, float n2)
{
    float temp=0;
    temp= n1+n2;
    return  n1, n2, temp;  // return temp
    //return (n1, n2, temp); // return temp
}
int main(void)
{
    float no1, no2, ans;
    printf("\n Enter no1::");
    scanf("%f", &no1);
    printf("\n Enter no2::");
    scanf("%f", &no2);

    ans=0;
    ans=addition(no1, no2); //3. function call
    // no1 , no2 is actual argruments
    printf("\n %.2f + %.2f = %.2f", no1, no2, ans);
   

    return 0;
}
