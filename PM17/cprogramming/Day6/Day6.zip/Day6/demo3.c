#include<stdio.h>
void table(int n);
int table_no(int n, int c);
int main(void)
{
    int no, cnt;
    printf("\n Enter No=");
    scanf("%d",&no);
    table(no);

    printf("\n print table of %d in main", no);
    for(cnt=1; cnt<=10; cnt++)
    {
        printf("\n%d * %d = %d", no, cnt, table_no(no,cnt));
    }

    return 0;
}
int table_no(int n, int c)
{
    return n*c;
}
void table(int n)
{
    int counter;
    printf("\n table of %d  in function table\n", n);
    for(counter=1; counter<=10; counter++)
        printf("\n %d * %d = %d", n, counter, n*counter);
    return;
}

/*
table() 1
main()  1
os    2

*/

/*
table_no(5,1)  10
main() 1
os     11
*/