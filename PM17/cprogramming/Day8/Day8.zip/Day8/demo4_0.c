#include<stdio.h>

int main(void)
{
    //int arr[ 5 ]={11,22};
    //             0   1
    //int arr[]={11,22,33,44,55};
   //          0  1  2  3   4
    int arr[ 4 ];
    int index;
    printf("\n eneter Elements of array \n");
    for(index=0; index< 4; index++)
    {
        printf("\n arr[%d] =", index);
        scanf("%d", &arr[index]);
    }
    printf("\n Elements of array \n");
    for(index=0; index<4; index++)
    {
        printf("\n arr[%d] %d [%u]",index, arr[index], &arr[index]);
    }

    printf("\n no of elements in array =%d", 4);
    printf("\n size of array in bytes =%d", 4*sizeof(int)); //4*4=16

    printf("\n arr=%u &arr=%u  &arr[0]=%u ", arr, &arr, &arr[0]);
    printf("\n arr+1=%u &arr+1=%u  &arr[0]+1=%u ", arr+1, &arr+1, &arr[0]+1);

    /*arr++;  // lvalue requried  ++5
    ++arr;
    arr--;
    --arr;
    */
    return 0;
}