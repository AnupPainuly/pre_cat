/*  no1  no2      no1 no2  no1 no2
fibo series
0    1    1   2    3   5   8   13   21  34 
no1 no2 no3  no1  no2  no1 no  no1 no2

try fun 
try recusrion
*/
#include<stdio.h>
int main(void)
{
    printf("\n ============int ================\n");
    {
        int i=10;   // variable
        int *pi=&i; // pointer
        // or
        //int *pi=NULL;
        //pi=&i;                     //          10    10
                                    // 10    *(1000) *(1000)
        printf("\n i=%d *(&i)=%d *pi=%d",i , *(&i), *pi);
        printf("\n &i=%u pi=%u &pi=%u", &i, pi, &pi);

        printf("\n sizeof(pi)=%d", sizeof(pi)); // 8 bytes (64 bit)

        *pi=20;                //        20    20   20
        printf("\n i=%d *(&i)=%d *pi=%d",i , *(&i), *pi);
        printf("\n &i=%u pi=%u &pi=%u", &i, pi, &pi);

        printf("\n pi=%u pi+1=%u", pi, pi+1);  // 100+1= 100+1*4
        printf("\n pi=%u pi-1=%u", pi, pi-1); // 100-1= 100-1*4
        
        printf("\n pi=%u pi+5=%u", pi, pi+5);  // 100+5*4 ==120
        printf("\n pi=%u pi-5=%u", pi, pi-5); //  100-5*4 == 80

      //  printf("\n pi=%u pi*5=%u", pi, pi*5);  // error
//        printf("\n pi=%u pi/5=%u", pi, pi/5); //  error

   // invalid operands to binary * (have ‘int *’ and ‘int’)
    }
    printf("\n ============== char============== \n");
    {
        char i='A';   // variable
        char *pi=&i; // pointer
        // or
        //char *pi=NULL;
        //pi=&i;                     //         'A'      'A'
                                    // 'A'    *(1000) *(1000)
        printf("\n i=%c *(&i)=%c *pi=%c",i , *(&i), *pi);
        printf("\n &i=%u pi=%u &pi=%u", &i, pi, &pi);

        printf("\n sizeof(pi)=%d", sizeof(pi)); // 8 bytes (64 bit)

        *pi='B';                //      B     B    B
        printf("\n i=%c *(&i)=%c *pi=%c",i , *(&i), *pi);
        printf("\n &i=%u pi=%u &pi=%u", &i, pi, &pi);

        printf("\n pi=%u pi+1=%u", pi, pi+1);  // 100+1= 100+1*4
        printf("\n pi=%u pi-1=%u", pi, pi-1); // 100-1= 100-1*4
        printf("\n pi=%u pi+5=%u", pi, pi+5);  //  100+5*1 ==105
        printf("\n pi=%u pi-5=%u", pi, pi-5); //   100-5*1 == 95


    }
     printf("\n ==============float============ \n");
    {
        float i=10.2f;   // variable
        float *pi=&i; // pointer
        // or
        //float *pi=NULL;
        //pi=&i;                     //        
                                          // 10.20    10.20  10.20
        printf("\n i=%.2f *(&i)=%.2f *pi=%.2f",i , *(&i), *pi);
        printf("\n &i=%u pi=%u &pi=%u", &i, pi, &pi);

        printf("\n sizeof(pi)=%d", sizeof(pi)); // 8 bytes (64 bit)

        *pi=22.34f;
                                      // 22.34    22.34       22.34
        printf("\n i=%.2f *(&i)=%.2f *pi=%.2f",i , *(&i), *pi);
        printf("\n &i=%u pi=%u &pi=%u", &i, pi, &pi);
        
        printf("\n pi=%u pi+1=%u", pi, pi+1);  // 100+1= 100+1*4
        printf("\n pi=%u pi-1=%u", pi, pi-1); // 100-1= 100-1*4
        
        printf("\n pi=%u pi+5=%u", pi, pi+5);  //  100+5*4 ==120
        printf("\n pi=%u pi-5=%u", pi, pi-5); //  100-5*4 == 80


    }
    return 0;
} // gcc -m32 demo1.c   // 32 bit compiler
  // gcc -m64 demo1.c   // 64 bit compiler
/*3    address                        data
     pi + 5  allowed          *pi + 5 allowed
     pi - 5  allowed          *pi - 5 allowed
     pi * 5  not allowed      *pi * 5 allowed 
     pi / 5  not allowed      *pi / 5 allowed
*/

/*4   pi + pj  not allowed       *pi + *pj allowed
      pi * pj  not allowed       *pi * *pj allowed
      pi / pj  not allowed       *pi / *pj allowed
*/

/*
      pi-pj  // allowed in case array 
*/