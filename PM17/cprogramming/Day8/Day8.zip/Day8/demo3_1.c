#include<stdio.h>
void sumproddiv(int n1, int n2, int *ps, int *pp, int *pd);
int main(void)
{
    int no1=20, no2=10, sum=0, prod=0, div=0;
    sumproddiv(no1, no2, &sum, &prod, &div);
    printf("\n %d + %d =%d ", no1, no2, sum);
    printf("\n %d * %d =%d ", no1, no2, prod);
    printf("\n %d / %d =%d ", no1, no2, div);
    return 0;
}
void sumproddiv(int n1, int n2, int *ps, int *pp, int *pd)
{
    *ps= n1+n2;  // *(200)= n1+n2;  *200= 20+10=30
    *pp= n1*n2;  // *(210)= n1*n2;  *200= 20*10=200
    *pd= n1/n2;  // *(210)= n1*n2;  *200= 20/10=2
    return;
}