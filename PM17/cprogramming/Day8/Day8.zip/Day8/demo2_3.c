// call by value
#include<stdio.h>
int n1=10, n2=20;
void swap(void); 

int main(void)
{
    printf("\n before swap in main no1=%d [%u] no2=%d[%u]", n1,&n1, n2, &n2);
    //swap(n1, n2); //error function call
    swap(); // function calls
    printf("\n before swap in main no1=%d [%u] no2=%d[%u]", n1,&n1, n2, &n2);
    return 0;
}

void swap(void)
{
    int temp=0;
    printf("\n before swap in swap n1=%d [%u] n2=%d[%u]", n1,&n1, n2, &n2);
    temp=n1;
    n1=n2;
    n2=temp;
    printf("\n after swap in swap n1=%d [%u] n2=%d[%u]", n1,&n1, n2, &n2);
    return;
}