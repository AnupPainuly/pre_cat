#include<stdio.h>
int main( void )
{
    int i=5;
    if (!printf("0"))    //if(!1)  if(0)  false
        i = 3;
    else
        i = 5;         
    printf("%d", i); //5
    
    return 0;
}  // 05 
/*
A. 3
B. 5
C. 05
D. 03

Anwer: C
*/