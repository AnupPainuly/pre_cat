//What value of c will get printed
#include <stdio.h>
int main(void)
{
    int a,b,c;
    a=printf("\nPG-DITISS");  // 10
    b=printf("\nPG-DMC"); //7
                 // 13             8   ==21
    c=printf("\nPG-DBDA [%d]",a )+ ++b;
            // \nPG-DBDA [10]
    printf(" %d",c); //21
    return 0;
}
/*
A. PG-DITISS
   PG-DMC
   PG-DBDA [10] 21
B. PG-DITISS
   PG-DMC
   PG-DBDA [10] 22
C. PG-DITISS
   PG-DMC
   PG-DBDA [11] 22
D. PG-DITISS
   PG-DMC
   PG-DBDA [11] 21
Answer: A
*/