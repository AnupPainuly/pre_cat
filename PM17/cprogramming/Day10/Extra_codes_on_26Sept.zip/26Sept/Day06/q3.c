#include<stdio.h>
int main( void )
{
    char check = 'a';
    again:
    if(check) //if(97)  if(1)
    {
        switch (check) // 97
        {            // 1 
              //        F       T
            ///    97==98     1
            case ('a'=='b' || 1 ) : printf("PG-DAC "); break; // case 1
            case  0   &&  'b'=='a' : printf("PG-DMC "); break; // case 0
            //     F        not check
              //        F
            default : printf("PG-DITISS"); break; // print  PG-DITISS
        }
    }
    else 
        goto again;

    return 0;
}
/*
A. PG-DAC
B. PG-DMC
C. PG-DITISS
D. compile-time error 

Answer: C
*/