#include<stdio.h>
int main( void )
{
    int x=101,y=202;                                       //       T
    if(!(!x) && x) // if(!(!101) && 101)  // if(!(0) && 101) // if(1 && 101)
         printf("inside if x=%d\n",x); // print inside if x=101
    else if(!(!x)&& x)
        printf("inside 1st netsed if x=%d\n",x);
    else if(!(!x)&& x)
        printf("inside 2ed netsed if x=%d\n",x);
    else
        printf("inside else y=%d\n",y);
    return 0;
}   
/*
A. inside else y=202
B. compile time error
C. inside if x=101
D. inside 1st netsed if x=101
E. inside 2ed netsed if x=101
Answer: C
*/