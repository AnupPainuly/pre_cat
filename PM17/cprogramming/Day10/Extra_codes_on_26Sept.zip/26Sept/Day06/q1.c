#include<stdio.h>
int main( void )
{
    char i = 48;
    switch (i)
    {
        case '2': printf("SunBeam Karad");break;  //50
        case '1': printf("SunBeam Market Yard");break;  // 49
        default : printf("SunBeam IT Park Hinjewadi");  //print
    }
    return 0;
}
/*
A. SunBeam Karad
B. SunBeam Market Yard
C. SunBeam IT Park Hinjewadi
D. Complile time error

Answer: C
*/