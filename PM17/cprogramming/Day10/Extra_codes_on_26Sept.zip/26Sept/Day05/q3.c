#include<stdio.h>
int main( void )
{
    int var1=100,var2=200;

    var2-= var1--;  // a-=10 ;  a= a-10;
    //var2 = (val2 - val1--);
    // 100    (200 - 100)    100     99       
    printf("var2=%d var1=%d",var2, var1);
    return 0;
}
/*
A. var2=101 var1=99
B. var2=100 var1=99
C. var2=101 var1=101
D. var2=99 var1=199

Answer: B
*/