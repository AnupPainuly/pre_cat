#include <stdio.h>
int main( void )
{
    int num1,num2,num3;
    num1 = 144;
    num2 = 156;
    //                   144+1=145    156+1=157
    num3 = printf("%10d",++num1 )+ ++num2;  // 10+157=167
    printf(" %d",num3);   // print 145    167 
    return 0;
}
/*
A. 144  166
B. 145  167
C. 145  168
D. 144  167

Answer: B
*/