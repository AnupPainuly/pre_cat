#include<stdio.h>
int main( void )
{
    int val1 = 0x64;
   // printf("\nval1=%d", val1); // 100
    int val2 = 064 + val1; //  064== 52  100+52=152
   // printf("\nval2=%d 064=%d", val2, 064);

    int val3 = 0x72 + 072 + 72 - val1 + val2;
    //         114  +  58  + 72- 100  + 152 == 296
   // printf("\n0x72=%d 072=%d " ,0x72,072);
    printf("val2=%d val3=%d\n",val2,val3); // val2 = 152 , val3=296
    return 0;
}
/*
A. val2=152  val3=296
B. val2=150  val3=298
C. val2=148  val3=288
D. val2=154  val3=297

Answer: A
*/