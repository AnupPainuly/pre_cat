#include <stdio.h>
int main(void)
{
    int value;       // false
         //false       1!=1              print 300
    value= 5>8 ? 100 : 1 != 5<=5 ? 200 : 300;
    printf("Value of value:%d",value);// 300
    return 0;
}
/*
A. Value of value:300
B. Value of value:200
C. Value of value:100
D. complie time error

Answer: A
*/