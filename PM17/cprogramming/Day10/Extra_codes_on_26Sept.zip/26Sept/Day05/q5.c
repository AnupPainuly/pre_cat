#include<stdio.h>
int main( void )
{
    int num1 = 0, num2 = -1 , num3 = -2, num4 = 1, ans;
    //                    T
    //                               T
 //             F                T      -2+1=-1
//          F                  1+1=2       T
//          0    not check       1        -2 
    ans = num1++ && num2++ || ++num4 && num3++;
    //    ================    ================
    printf("%d %d %d %d %d",num1, num2, num3, num4, ans);
    return 0; //              1     -1   -1    2     1   
}
/*
A. 0  0 -1  2  0
B. 0 -1 -1  2  1
C. 1  0 -1  2  0
D. 1 -1 -1  2  1

Answer: D
*/