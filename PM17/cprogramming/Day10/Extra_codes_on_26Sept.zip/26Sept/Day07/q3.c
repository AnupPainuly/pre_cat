//What's going to happen when we compile and run the following C program?
#include <stdio.h>
int main( void )
{
    int value = 0;
    for ( ; value < 7 ; )
    {
        if (value < 7)
        {
            printf("Sun");
            ++value;         //0 1 2 3 4 5 6  7
        }
        else
            continue; // next iteratiom
            printf("Beam");

    }
    return 0;
}
/*
A. Compile Error due to use of continue in for loop.
B. No compile error but it will run into infinite loop printing Sun.
C. No compile error and it will print SunBeam 7 times followed by Beam once.
D. No compile error and it will print SunBeam 7 times

Answer: D
*/