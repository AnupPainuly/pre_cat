#include <stdio.h>
int main( void )
{
    int value1 = 4, value2 = 0 ;
    while ( value1 >= 0 ) // 4>=0  3>=0  2>=0 
    {
        if ( value2 == value1 )   //(4==0) (3==1) (2==2)
            break;  // out of loop
        else              //     4      0    3   1   
            printf ( "%d %d ", value1, value2 ) ;
        ++value2 ; //0+1=1 1+1=2
        --value1 ; //4-1=3 3-1=2  
    }
    return 0;
} // print 4 0 3 1
/*
A. 4 0 3 1
B. 4 1 3 1
C. 4 0 3 2
D. 4 2 3 1
Answer: A
*/