//How many times the below loop will run ?
#include <stdio.h>
int main( void )
{
    int value;
    value=0;
    do
    {
        ++value ; // 0  1  0 1
        printf("\n %d",value);  // 1 1
        value--; //0  0
    }while(value>=0); // true
    // print 1 infinite times
    return 0;
}
/*
A. 1
B. prints 1 Infinite times
C. 0
D. Compilation Error

Answer: B
*/