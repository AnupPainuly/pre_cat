//How many times will SunBeam IT Park be printed in this program?
#include <stdio.h>
int main( void )
{
    int i = 1;
    for ( ; i<1024 ; i <<= 1)
        printf("\n SunBeam IT Park");  // print 10 times
    return 0;
} //  i =  1 2  4    8  16   32 64  128  258   512  1024
/*
A. 10
B. 11
C. Infinite
D. The pro>gram will show compile-time error

Answer: A
*/