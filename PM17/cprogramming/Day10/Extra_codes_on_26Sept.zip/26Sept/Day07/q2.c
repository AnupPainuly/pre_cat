#include<stdio.h>                //  num1+num2-1 =3+2-1 ==4 
int main( void )                 //               2+2-1  ==3
{                             //                  1+2-1 ==2
    int num1=3,num2=2;         //                 0+2-1  ==1
    while(num1+num2-1)        //                -1+2-1   ==0
    {
        printf(" %d ",num1-- + num2);  //5 4   3  2
    }
    return 0;
}                    
              
/*
A. 4 3 2 1
B. 5 4 3 2
C. 6 4 2 1
D. 5 4 3 1

Answer: B
*/