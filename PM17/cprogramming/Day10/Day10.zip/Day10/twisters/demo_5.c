#include<stdio.h>
int main(void)
{
               // 0  1   2  3  4
    int arr[5]={11,22,33,44,55};

    /*arr++;
    ++arr;
    arr--;    not allowed
    --arr; */   
    // due to cdecl calling cov  right to left

    //                    25       24           23
    //                    24         23           22
    printf("%d %d %d", ++arr[1], ++arr[1], ++arr[1]);
//                              <-------
//                          27           26        25
//                          27          26         25                                                               
    printf("\n%d %d %d", arr[1]++, arr[1]++, arr[1]++);
      
    return 0;
}