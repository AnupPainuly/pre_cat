#include<stdio.h>
int main(void)
{
    unsigned int no=10;
    printf("\n -2= %u", -2);  // 4294967294
    if(no>-2)   //if(10>4294967294)
        printf("\n yes");
    else
        printf("\n no");  // print no
    {
        signed int no=10;
        printf("\n -2= %d", -2);  // -2
        if(no>-2) // if(10>-2)
            printf("\n yes");  // print yes
        else
            printf("\n no");
    }
    
    
    return 0;
}