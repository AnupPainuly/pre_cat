#include<stdio.h>
int main(void)
{
    // sizeof return unsigned int value
    printf("\n %u", -1); // 4294967295
    if (sizeof(2)>-1)    // if(4>4294967295)   // if (false) 
        printf("yes");     
    else
        printf("no");  // print no
    return 0;
}