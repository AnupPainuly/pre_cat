
#include<stdio.h>
int main(void)
{

    float pi=3.142f;
    float *ptr= &pi;
    float pj=10.2f;

    printf("\n pi=%.3f", pi); // 3.142
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=3.142

    *ptr= 4.4f;  // *(100)==4.400   allowed as value of pointer is not constant
    printf("\n pi=%.3f", pi); // 4.400
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=4.400
    printf("\n sizeof ptr=%d", sizeof(ptr));
    // using pointer we can modify value of pi;
    return 0;
}