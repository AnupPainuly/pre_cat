#include<stdio.h>
#include<string.h>
#define LEN 40
char* mystrstr(const char *s1,const char *s2);
int main(void)
{
    char src[LEN], *ptr=NULL, dest[LEN];
    int ans;

    printf("\n Enter src :: ");
    //scanf("%s", src); // src is name of array is base address
    // %s will scan upto space (single word)
    gets(src); // scan upto new line

    printf("\n Enter char to dest :: ");
    gets(dest);
    // gcc        turboc strcmpi

    ptr= strstr(src, dest);
    if(ptr== NULL)
        printf("\n %s is not found in  %s", dest, src);
    else
        printf("\n %s is found in  %s at %d location", dest, src, ptr- src);


    
    return 0;
    
}
