#include<stdio.h>
#include<string.h>
#define LEN 40
char* mystrcpy(char *d,const char *s);
int main(void)
{
    char src[LEN], *ptr=NULL, dest[LEN];
    size_t ans;

    printf("\n Enter src :: ");
    //scanf("%s", src); // src is name of array is base address
    // %s will scan upto space (single word)
    gets(src); // scan upto new line

    printf("\n Enter char to dest :: ");
    gets(dest);


    ptr= strcpy(dest, src);
    printf("\n dest=%s using parameter", dest);
    printf("\n ptr=%s using return value", ptr);
    

      ptr= mystrcpy(dest, src);
    printf("\n dest=%s using parameter using mystrcpy", dest);
    printf("\n ptr=%s using return value", ptr);
    return 0;
    
}
char* mystrcpy(char *d,const char *s)
{
    int index;
    //for(index=0; s[index]!='\0'; index++)
    for(index=0; *(s+index)!='\0'; index++)
    {
        *(d+index)= *(s+index);
        // d[index]=s[index];
    }
    *(d+index)='\0';  // d[index]='\0
    return d;
}

// return 10; int
// return 10.2; double
// return 10.2f; float
//return 'A'; char
//return;  void
// return "sunbeam";  char*