#include<stdio.h>
#include<string.h>
#define LEN 40
size_t mystrlen(const char *s);
int main(void)
{
    char src[LEN];
    size_t ans;

    printf("\n Enter src :: ");
    //scanf("%s", src); // src is name of array is base address
    // %s will scan upto space (single word)
    gets(src); // scan upto new line

    ans= strlen(src);
    printf("\n length of %s is %d using strlen from string.h", src, ans);

    ans= mystrlen(src);
    printf("\n length of %s is %d using mystrlen function", src, ans);

    return 0;
    return 0;
}

size_t mystrlen(const char *s)
{
    /*
    size_t index;
    index=0;
    while(s[index]!='\0')
    {
        index++;
    }
    return index;
    */

    size_t index;
    //for(index=0; *(s+index)!='\0'; index++);

    for(index=0; *(s+index)!='\0'; index++)
    {
        
    }
    return index;

} // s[index] == index[s] ==  *(s+index) == *(index+s)




