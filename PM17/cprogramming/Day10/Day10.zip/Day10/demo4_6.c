#include<stdio.h>
#include<string.h>
#define LEN 40
int mystrcmp(const char *s1,const char *s2);
int main(void)
{
    char src[LEN], *ptr=NULL, dest[LEN];
    int ans;

    printf("\n Enter src :: ");
    //scanf("%s", src); // src is name of array is base address
    // %s will scan upto space (single word)
    gets(src); // scan upto new line

    printf("\n Enter char to dest :: ");
    gets(dest);
    // gcc        turboc strcmpi
    ans= strcasecmp(src, dest);  // ingore case (upper or lower)
    if(ans==0)
        printf("\n %s (src) is equal to %s(dest", src, dest);
    else if(ans>0)
        printf("\n %s (src) is bigger  %s(dest)", src, dest);
    else if(ans<0)
        printf("\n %s (src) is smaller  %s(dest)", src, dest);
        
    
    return 0;
    
}
