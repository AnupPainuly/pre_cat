/* case  1  pi variable is constant
            value of pointer is not constant
            address of pointer is not constant
*/
#include<stdio.h>
int main(void)
{
    //const float pi=3.142f;
    float const  pi=3.142f;   // pi variable is constant
    float *ptr= &pi;//value of pointer is not constant & address of pointer is not constant

    float pj=10.2f;

    //pi=4.400f;  // = operator is not allowed as variable  pi is constant
    /*pi++;
    ++pi;
    pi--;          ++ -- pre post not allowed as variable pi is constant
    --pi; */

    /*pi+=10;
    pi-=10;
    pi*-10;     short hand operators are not allowed with constants
    pi/-10;
    */
    printf("\n pi=%.3f", pi); // 3.142
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=3.142

    *ptr= 4.4f;  // *(100)==4.400   allowed as value of pointer is not constant
    printf("\n pi=%.3f", pi); // 4.400
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=4.400

    ptr=&pj;  // allowed as address of  is not constant
    printf("\n pj=%.3f", pj); // 10.200f
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(200)=10.200f

    printf("\n sizeof ptr=%d", sizeof(ptr));
// using pointer we can modify value of pi;
    return 0;
}