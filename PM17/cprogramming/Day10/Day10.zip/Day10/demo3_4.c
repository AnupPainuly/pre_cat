/* case  4  pi variable is constant
            value of pointer is  constant
            address of pointer is constant
*/
#include<stdio.h>
int main(void)
{
    //const float pi=3.142f;
    float const  pi=3.142f;   // pi variable is constant
    //const float * const ptr= &pi;//value of pointer is  constant & address of pointer is  constant
    float const  * const ptr= &pi;
    float pj=10.2f;

    //pi=4.400f;  // = operator is not allowed as variable  pi is constant
    /*pi++;
    ++pi;
    pi--;          ++ -- pre post not allowed as variable pi is constant
    --pi; */

    /*pi+=10;
    pi-=10;
    pi*-10;     short hand operators are not allowed with constants
    pi/-10;
    */
    printf("\n pi=%.3f", pi); // 3.142
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=3.142

    //*ptr= 4.4f;  // *(100)==4.400  not allowed as value of pointer is constant
    printf("\n pi=%.3f", pi); // 3.142
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=3.142

    //ptr=&pj;  // nor allowed as address of  is  constant
    printf("\n pj=%.3f", pj); // 10.200f
    printf("\n *ptr=%.3f", *ptr);  // *(ptr)==*(100)=3.142

    printf("\n sizeof ptr=%d", sizeof(ptr));
// if value of pointer is   constant  we can  modify value of pi(variable)
// if address of pointer is   constant  we can  modify address store in pointer
    return 0;
}