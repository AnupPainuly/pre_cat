// string and array of char
// scan sets
// constant combination with pointers
// string functions	
// twisters on array
// void pointer


