// scan sets
#include<stdio.h>  
#include<string.h>  
#define LEN 40
int main(void)
{
    // string
    char city[LEN];

    printf("\n Enter city ::");
    //scanf("%s", city); // new delhi
    // scan upto 1st space (single word)

    //gets(city); // it will scan upto \n new line char line
    //scanf("%[^\n]s", city); // upto new line char
    //scanf("%[^.]s", city); // it will scanf upto . char
    // multine line string
    //scanf("%[^*]s", city);
    // it will scanf upto * char
    // it will scan upto multople  line string
    //scanf("%[A-Z]s", city);
    // scan uptp capital A-Z   ABCDxyz   ABCD
    //  scanf("%[a-z]s", city);
    // scan upto capital a-z   abcdXYZ   abcd
    //  scanf("%[0-9]s", city);
    // scan upto digits   1234abcdXYZ   1234
   // scanf("%[^A-Z]s", city);
    // scan uptp capital A-Z   xyzABCD   xyz
    // scanf("%[^a-z]s", city);
    // scan uptp capital A-Z   xyzABCD   xyz
    
    printf("\n city=%s", city);


    return 0;
}

/*
Meeting ID: 540 342 2999
Passcode: sunbeam
*/



