#include<stdio.h>
#include<string.h>
#define LEN 40
char* mystrcat(char *d,const char *s);
int main(void)
{
    char src[LEN], *ptr=NULL, dest[LEN];
    size_t ans;

    printf("\n Enter src :: ");
    //scanf("%s", src); // src is name of array is base address
    // %s will scan upto space (single word)
    gets(src); // scan upto new line

    printf("\n Enter char to dest :: ");
    gets(dest);


    ptr= strcat(dest, src);
    printf("\n dest=%s using parameter", dest);
    printf("\n ptr=%s using return value", ptr);
          
    return 0;
    
}
