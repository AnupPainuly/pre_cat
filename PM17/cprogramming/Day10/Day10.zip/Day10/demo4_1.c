#include<stdio.h>
#include<string.h>
#define LEN 40
char* mystrchr(const char *s, int find);
int main(void)
{
    char src[LEN], *ptr=NULL, search_char;
    size_t ans;

    printf("\n Enter src :: ");
    //scanf("%s", src); // src is name of array is base address
    // %s will scan upto space (single word)
    gets(src); // scan upto new line

    printf("\n Enter char to search :: ");
    scanf("%c", &search_char);

    ptr= strchr(src, search_char);
    if(ptr==NULL)
        printf("\n %c is not found in %s using string.h", search_char, src);
    else
        printf("\n %c is found in %s  at %d location using string.h", search_char, src, ptr- src);
    
    
    ptr= mystrchr(src, search_char);
    if(ptr==NULL)
        printf("\n %c is not found in %s using mystr fun", search_char, src);
    else
        printf("\n %c is found in %s  at %d location using my str fun", search_char, src, ptr- src);
    

    return 0;
    
}
char* mystrchr(const char *s, int find)
{
   /* int index;
    for(index=0; s[index]!='\0'; index++)
    {
        if(find== s[index])
            return &s[index];
    }
    return NULL;
    */
   int index;
    for(index=0; *(s+index)!='\0'; index++)
    {
        if(find== *(s+index))
            return (s+index);
    }
    return NULL;
}
// return 10; int
// return 10.2; double
// return 10.2f; float
//return 'A'; char
//return;  void
// return "sunbeam";  char*