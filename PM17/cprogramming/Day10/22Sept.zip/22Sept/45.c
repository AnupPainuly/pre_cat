#include <stdio.h>
#include <string.h>
int main()
{
    char *s = "SunBeam"; int i; char * p = s;
    for(i = 0; i <strlen(p); ++i, ++p)
        printf("%c", *p++);  
    return 0;
} // output Sne
/*
  i   strlen(p)     Sne
  0      7   true
  1      5   true
  2      3   true
  3      1   false
*/