#include <stdio.h>
int main()
{
    static char *s = "SunBeam";
    char ch = *s;
    if(*s)
    {
        ++s; 
        printf("%c", ch);
        main(); 
    }
    return 0;
}  //print SunBeam