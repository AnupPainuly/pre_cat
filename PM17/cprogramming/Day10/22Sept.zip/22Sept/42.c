#include <stdio.h>
int main(void)
{            // 0  1  2
    int a[] = {1, 2, 3};
    printf("%d", a[a[1]]);  //a[1]=2   a[2]==3
    return 0;
} //print 3