#include <stdio.h>
#include <string.h>
int main()
{
    char *s = "SunBeam"; int i; char * p = s;
    for(i = 0; i <strlen(s); ++i, ++p)
        printf("%c", p[-i]);
    return 0;
}
 /* strlen(s) == 7    p="SunBeam"     SSSSSSS
  i      7    p[-i]
  0           *(p-i) *(p-0) *p
  1      7    *(p-1) *(p-1) 
  2      7    *(p-i) *(p-2)  
  3      7    *(p-i)  *(p-3)
  4      7    *(p-i)  *(p-4)
  5      7    *(p-i)  *(p-5)
  6      7    *(p-i)  *(p-6)
  7      7   false  out of loop
 */