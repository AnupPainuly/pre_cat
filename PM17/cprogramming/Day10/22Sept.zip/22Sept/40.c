
int main(void)
{ // array
    int a[] = {1, 2, 3}; //3*4     size of int 4
    printf("%d, %d, ", sizeof(a), sizeof(a[-1]));
    print_size(a);
    return 0;
}
int print_size(int a[])
{             // pointer 4 bytes size of int 4 bytes 
    printf("%d, %d, ", sizeof(a), sizeof(a[3]));
    return 0;
} // 12  4 4  4