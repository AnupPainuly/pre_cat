#include <stdio.h>
int main()
{ 
    int a[] = {1, 2, 3}; //array
     //      100 104 108 
    f(a);
    return 0;
}
int f(int a[]) // 100
{ // 104
    ++a;   // pointer allowed
    printf("%d", a[-1]); // a[i]== *(a+i) == *(104-1) == *(100)   ==1
    return 0;  
} //print 1