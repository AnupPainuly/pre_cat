#include <stdio.h>
int main()
{
    static char *s = "SunBeam";
    char ch = *s;
    if(*s)
    {
        ++s; 
        main(); 
        printf("[%c]", *s);
    }
    return 0;
} // no output   s points at last \0

/*
*****
****
***
**
*

*****1
****21
***321
**4321
*54321


*****11
****2112
***321123
**43211234
*5432112345


*****11
****2112
***321123
**43211234
*5432112345
*5432112345
**43211234
***321123
****2112
*****11


ABCDEDCBA
ABCD DCBA
ABC   CBA
AB     BA
A       A
AB     BA
ABC   CBA
ABCD DCBA
ABCDEDCBA




pascal triange
    1
   1 1
  1 2 1
 1 3 3 1  

*/