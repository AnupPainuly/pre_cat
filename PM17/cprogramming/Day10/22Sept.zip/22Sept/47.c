#include <stdio.h>
int main(void)
{
    char *s = "SunBeam";char p[7] = "SunBeam";
    printf("%d, %d, %d, %d", sizeof(s), sizeof(p),sizeof(*p), sizeof("sunbeam"));
      //                        4         7*1=7    sizeof(char)      7+1=8
      //                                               1
    return 0;
} // 4 7 1  8