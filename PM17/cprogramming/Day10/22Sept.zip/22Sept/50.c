// 4*4 +3*3 == 5*5

#include<stdio.h>
int main()
{
    int i, j, k, cnt=1;
    for(i=1; i<=25; i++)
    {
        for(j=1; j<=25; j++)
        {
            for(k=1; k<=25; k++)
            {
                if( (i*i + j*j) == k*k)
                {
                    printf("\n%d] %d*%d + %d*%d =%d * %d",cnt++, i, i, j,j, k, k);
                }
            }
        }
    }
    return 0;
} // avoid duplicate triplates