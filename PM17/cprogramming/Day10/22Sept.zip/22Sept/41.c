#include <stdio.h>
int main()
{
    int a[] = {1, 2, 3};
    ++a; // error  l- value requried 
    printf("%d", a[2]);
    return 0;
}// compile time error