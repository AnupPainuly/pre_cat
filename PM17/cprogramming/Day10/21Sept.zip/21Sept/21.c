#include <stdio.h>
#include<math.h>
int main(void)
{
    int main = 49;
    printf("%f", sqrt(main));
    return 0;                              /// for math.h 
} // how to compile  gcc 21.c    -o 21.out -lm   on linux/ mac
 //                     progname    outputfile name
 //how to compile  gcc 21.c    -o 21.exe -lm   on window