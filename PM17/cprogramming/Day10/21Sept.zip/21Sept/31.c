#include <stdio.h>
int main(void) // data segment
{
    int main = 3;  // allowed   stack
    printf("%o", main);
    return 0;
}