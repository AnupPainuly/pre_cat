#include <stdio.h>
int sunbeam()
{
    int a=3;
    return a*a;  //3*3=9
}
int main(void)
{
    int a = 3;
    printf("%d", sunbeam(a)); // 9
    return 0;
}