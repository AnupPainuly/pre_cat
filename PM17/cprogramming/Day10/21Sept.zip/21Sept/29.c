#include <stdio.h>
int main(void)
{
    int x = 3;  // stack
    static int y = x; // error (data seg)
    // we can init static var with constant or default zero
    // we can not init static with local variables 
    printf("%d, %d", x, y);
    return 0;
}