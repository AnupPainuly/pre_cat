20.
During function call actual arguments are copied into
formal arguments.
21.
main() is entry point function for a C program.

22.
fun decl of library function is kept in header files and
their fun defination are kept in library files.

23.
