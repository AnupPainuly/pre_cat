#include <stdio.h>
int main()
{
    int i, j;
    for(i = 1; i <= 3; i+=2);
        for(j = 1; j <= 3; j+=2)
            printf("%d, %d, ",i, j);
    return 0;
} /*        5   1   5   3
    i    j
    1  
    1+2=3
    5    1
    5    3
    5    5
*/