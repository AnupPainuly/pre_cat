#include <stdio.h>
extern int x;   // decl of global
int main(void)
{
printf("%d", x); // 0 
} int x;  // defination of global