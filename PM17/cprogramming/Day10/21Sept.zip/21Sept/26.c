#include <stdio.h>
int sunbeam(int **q)
{
    int a =**q * **q; /*$$$*/;
    return a;
}
int main(void)
{
    int a = 3;
        int *p = &a;
    a=sunbeam(&p);
    printf("%d", a);
    return 0;
}