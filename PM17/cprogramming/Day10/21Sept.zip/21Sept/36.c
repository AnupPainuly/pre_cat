#include <stdio.h>
#define greater(a, b) (a > b)? a : b
int main(void)
{
    int x = 3, y = 4;
    //    if((x > y)? x : y)  // 

    if(greater(x, y))  // if( (3 >4) ? 3 : 4)  if(4)  non zero true
        printf("sun");  // print sun
    else
        printf("beam");
    return 0;
}
