#include <stdio.h>
int main(void)
{
    int i, j;
    for(i = 1; i <= 3; i+=2)
        for(j = 1; j <= 3; j+=2)
            printf(" %d, ", i+j);
    return 0;
}  /*  2   4    4   6
      i   j
      1   1         1+1=2
      1   3         1+3=4
      1   5         3+1=4
      3   1         3+3=6  
      3   3
      3   5
*/