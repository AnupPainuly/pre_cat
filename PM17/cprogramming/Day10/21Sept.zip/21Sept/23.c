#include <stdio.h>
int main(void)
{
    int a = 1;
    int *p = &a;    
    int *q = p;
    *p = *p + *q;   //*p= *(100)=2  a=2  *(q)  *100=2
    printf("%d %d %d",*p,a,*q); //2 2  2
    return 0;
}