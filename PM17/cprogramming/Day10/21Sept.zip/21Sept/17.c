#include <stdio.h>
int main(void)
{
char i = 0;
    do
    {
        printf("%d, ", i);
    }while(i--); // while(0)
    return 0; //print 0
}