#include <stdio.h>
int main(void)
{
register int x = 3;
printf("%p, %x", &x, x);  //error we cant print address of registor var
return 0;
}