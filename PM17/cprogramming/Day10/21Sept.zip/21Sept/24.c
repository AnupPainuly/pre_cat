#include <stdio.h>
int sunbeam()
{
    return a*a;  //error: ‘a’ undeclared 
}
int main(void)
{
    int a = 3;
    printf("%d", sunbeam());
    return 0;
}