#include <stdio.h>
int main(void)
{
    char i = 0;  // signed char -128 to 127
    do
    {
        printf("%d, ", i);
    }while(--i);  //0 -1 -2                   -128 127   126     1
    return 0;
}