#include <stdio.h>
int main(void)
{
    printf("line no =%d", __LINE__);  // prints line no
    printf("\n file name=%s", __FILE__); //print 39.c
    printf("\n date= %s",__DATE__);
    printf("\n Time = %s",__TIME__);
    return 0;
}