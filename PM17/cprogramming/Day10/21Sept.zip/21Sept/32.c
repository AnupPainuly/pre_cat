#include <stdio.h>
int main = 3;  // data seg
int main(void)// data seg
{
printf("%o", main);
return 0; //error: ‘main’ redeclared as different kind of symbol
}// we can not decl  function name as var name