#include <stdio.h>
int main(void)
{
    int a = 1;                 //  if u dont give termination cond 
                               // then stack overflow
    printf("%d", ++a);
    main();
    return 0;
}  // 1.  print 222 and stack overflow
    // 2  runtime error 