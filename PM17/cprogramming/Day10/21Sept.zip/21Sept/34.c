#include <stdio.h>
#define area(x) (x * x)
int main(void)
{
    printf("\n%d ",area(6 + 3)); // (6+3*6+3) // 6+18+3= 27
    printf("\n%d ",area( (6 + 3))); // ((6+3)* (6+3)) // 9*9 ==81
    return 0;
}