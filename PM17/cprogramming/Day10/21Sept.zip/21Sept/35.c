#include <stdio.h>
#define print_mul(x, y) printf("%d * %d = %d", x,y,x*y)
int main(void)
{
int a = 3;
print_mul(a, 3); // printf("%d * %d = %d", a,3,a*3); // 3*3 = 9

return 0;
} // gcc -E -0 35.i 35.c