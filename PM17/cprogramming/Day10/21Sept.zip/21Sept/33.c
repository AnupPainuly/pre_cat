#include <stdio.h>
int x = 3; // global var
int main(void)
{
    int x = 4, i;  // local to main
    for(i = 0; i < x; ++i)
    {
        int x = 0; // local to block of for loop 
        printf("%d ,", x++); // post incre 0  0  0  0
    }
    return 0;
}