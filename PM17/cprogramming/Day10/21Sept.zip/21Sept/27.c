#include <stdio.h>
register int x;  // error we can decl register locally not globally
int main(void)
{
printf("%x", x);
}