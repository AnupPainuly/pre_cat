#include <stdio.h>
#define max(a, b) (a > b)? a : b
int main()
{
    int x = 3, y = 4, z;
    //       4 > 4
      //     3   4             5 
   // z=  (++x > y++) ? ++x : y++;  6
   //      
    z = max(++x, y++);//  4  6  5
    printf("%d, %d, %d", x, y, z);

    return 0;
}