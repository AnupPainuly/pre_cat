// printf scanf returns
// left and right allignments
// type casting
// range of data types (add of char and multiply of short int)
// alogo flowchart
// scanf of char and int 
// pre post increment / decrement
// and or not (twisters)
// octal hex decimal
#include<stdio.h>
int main(void)
{
    // init at time of decl of var
    int no1=0;// no1 is variable of int data type
    no1=5; // assigment of value to varible
    no1= printf("SunBeam");
    printf("\n no1=%d", no1);
    no1= printf("\nSunBeam\tPune");
    printf("\n no1=%d", no1);

    printf("\n no1=%d", printf(" SunBeam Pune Karad "));
    return 0;
}
