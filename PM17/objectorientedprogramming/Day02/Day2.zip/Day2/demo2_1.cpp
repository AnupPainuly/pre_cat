// class in cpp  using this pointer
#include<iostream>
using namespace std;
#pragma pack(1)
class book
{ 
    private:
        // varibale / data members / fields
        int bookid;
        char bookname[10];
        float price;
    // member function / methods
    public:
        //void accept_bookinfo(book *const this)
        void accept_bookinfo()
        {
            cout<<"\n Enter book id::";
            cin>>this->bookid;
            cout<<"\n Enter book name::";
            cin>>this->bookname;
            cout<<"\n Enter book price::";
            cin>>this->price;
            return;
        }
        //void dispaly_bookinfo(book * const this)
        void dispaly_bookinfo()
        {
            cout<<"\n book no ="<< this->bookid<<endl;
            cout<<"\n book nane ="<< this->bookname<<endl;
            cout<<"\n book price ="<<this->price;
            return;
        }
        //void set_price(book * const this,float price)

        void set_price(float price)
        {
            this->price= price;
        }
};

int main()
{
    book b1;//class book b1;       
    book b2;//class book b2;       
    float p;
    cout<<"\n Enter book info for b1 :: \n";
    b1.accept_bookinfo();// accept_bookinfo(&b1);

    cout<<"\n book info for b1 ::\n";
    b1.dispaly_bookinfo();  //dispaly_bookinfo(&b1);

    cout<<"Enter new price::";
    cin>>p;

    b1.set_price(p);
    cout<<"\n book info for b1 ::\n";
    b1.dispaly_bookinfo();  //dispaly_bookinfo(&b1);


  
    cout<<"\n Enter book info for b2 :: \n";
    b2.accept_bookinfo();// accept_bookinfo(&b2);

    cout<<"\n book info for b2 ::\n";
    b2.dispaly_bookinfo();  //dispaly_bookinfo(&b2);

    return 0;
}