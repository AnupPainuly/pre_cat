// types of member fun 
// 1. facility of input and output
// 2. ctor
// 3. dtor ~
// 4. inspector -- gettor method
   // inspector dont change state of the object
// 5. mutator -- settor method
      // mutators modify state of the object
#include<iostream>
using namespace std;
class Complex
{
    private: // variable/ data member / field
        int real;
        int imag;
    public: // member function/ methods
        //1.1 input
        //void accept_input(Complex * const this)
        void accept_input()
        {
            cout<<"Enter real=";
            cin>>this->real;
            cout<<"Enter imag=";
            cin>>this->imag;
        }
        //1.2 output
        void display_output()
        {
            cout<<"this->real="<<this->real<<"\t["<<&this->real<<"]"<<endl;
            cout<<"this->imag="<<this->imag<<"\t["<<&this->imag<<"]"<<endl;
        }
        // gettor method inspector
        //int get_real(Complex * const this)
        int get_real()
        {
            return this->real;
        }
        //int get_imag(Complex * const this)
        int get_imag()
        {
            return this->imag;
        }
    
};
int main()
{
    Complex c1;
    c1.accept_input();
    int r, i;
    r= c1.get_real();
    i= c1.get_imag();
    cout<<"c1="<<endl;
    cout<<"r of c1="<<r<<endl;
    cout<<"i of c1="<<i<<endl;
    cout<<"c1="<<endl;
    c1.display_output();

    return 0;
}
