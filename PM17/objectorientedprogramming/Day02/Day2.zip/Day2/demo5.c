#include<stdio.h>
int main(void)
{
    const float pi=3.142f;
    float *ptr=&pi;

    printf("\n pi=%.2f *ptr=%.2f", pi, *ptr);

    *ptr=4.3f;
    printf("\n pi=%.2f *ptr=%.2f", pi, *ptr);
// in c prog we can modify the value of constant variable using pointer
    return 0;
}
