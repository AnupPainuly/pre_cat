#include<iostream>
int main()
{
    {
        int no1, no2;
        std::cout<<"Enter no1::";
        std::cin>>no1;  // allowed
        //std::cin>>&no1; //error scanf("%d", &no1);
        std::cout<<"Enter no2::";
        std::cin>>no2; 

        std::cout<<"no1="<<no1<<"\t &no1="<<&no1<<std::endl;
        std::cout<<"no2="<<no2<<"\t &no2="<<&no2<<"\n";
    }
    return 0;
}
