#include<iostream>
using namespace std;
class ConstDemo
{
    private:
        int a;
        int b;
        const int c;
        int const d;
    public:
    // ctor int list
        ConstDemo():a(10), b(20), c(30), d(40)
        {
            //this->a=10; // allowed as a, b are not constant data members
            //this->b=20;
            //this->c=30;// not allowed as c, d are  constant data members
            //this->d=40;
        }

        ConstDemo(int a, int b, int c, int d):a(a), b(b), c(c), d(d)
        {
            //this->a=a; // allowed as a, b are not constant data members
            //this->b=b;
            //this->c=c;// not allowed as c, d are  constant data members
            //this->d=d;
        }
//      void display(ConstDemo * const this)
        void display()
        {
            this->a=111;  // a, b can be modify as they are non constant
            this->b=222;
            //this->c=333;// c, d can not be modify as they are constant
            //this->d=444;
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
            cout<<"this->c="<<this->c<<endl;
            cout<<"this->d="<<this->d<<endl;
        }
        // if we  make member function as constant we can not modify state of the object
        //void print(const ConstDemo * const this)
        void print()const
        {
            //this->a=111;  // a, b can not be modify as member function is constant
            //this->b=222;
            //this->c=333;// c, d can not be modify as they are constant
            //this->d=444;
            cout<<"this->a="<<this->a<<endl;
            cout<<"this->b="<<this->b<<endl;
            cout<<"this->c="<<this->c<<endl;
            cout<<"this->d="<<this->d<<endl;
        }
        ~ConstDemo()
        {
            this->a=0;   // allowed as a, b are not constants
            this->b=0;
            //this->c=0;// not allowed as c, d are constants
            //this->d=0;
        }
};

int main()
{
    
    ConstDemo c1; // parameterless
    cout<<"c1 print()"<<endl;
    // non constant object can call non constant member
    c1.print();
    cout<<"c1="<<endl;
    // non constant object can call constant member
    c1.display();

   const  ConstDemo c2(11,22,33,44); // parameterized
   // constant object can call constant member
    cout<<"c2 print()"<<endl;
    c2.print();
    
    cout<<"c2="<<endl;
    // constant object can not call non constant member
    //c2.display();
    return 0;
}
