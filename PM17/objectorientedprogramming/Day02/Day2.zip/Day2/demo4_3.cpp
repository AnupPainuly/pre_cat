// types of member fun 
// 1. facility of input and output
// 2. ctor
// 3. dtor ~

#include<iostream>
using namespace std;
class Complex
{
    private: // variable/ data member / field
        int real;
        int imag;
    public: // member function/ methods
        //1.1 input
        //void accept_input(Complex * const this)
        void accept_input()
        {
            cout<<"Enter real=";
            cin>>this->real;
            cout<<"Enter imag=";
            cin>>this->imag;
        }
        //1.2 output
        void display_output()
        {
            cout<<"this->real="<<this->real<<"\t["<<&this->real<<"]"<<endl;
            cout<<"this->imag="<<this->imag<<"\t["<<&this->imag<<"]"<<endl;
        }
        // 2.1  parameterless ctor or no argument ctor
        // Complex(Complex * const this)
        Complex()
        {
            this->real=10;
            this->imag=20;
            cout<<"inside parameterless ctor of Complex class"   <<endl;
        }
        // 2.2  parameterized ctor with one argrments
        // Complex(Complex * const this, int value)
        Complex(int value)
        {
            this->real=value;
            this->imag=value;
            cout<<"inside parameterized ctor  with one argument of Complex class"   <<endl;
        }
      // 2.3  parameterized ctor with two argrments
      // Complex(Complex * const this, int real, int imag)
        Complex(int real, int imag)
        {
            this->real=real;
            this->imag=imag;
            cout<<"inside parameterized ctor  with two argument of Complex class"   <<endl;
        }

        // 3. dtor
        ~Complex()
        {
            cout<<"==================="<<endl;
            this->display_output();
            cout<<"==================="<<endl;
            this->real=0;
            this->imag=0;
            cout<<"inside dtor of complex class"<<endl;
        }

};
int main()
{
    Complex c1;  // paramterless ctor
    cout<<"c1::"<<endl;
    c1.display_output(); // real=10 imag=20

    Complex c2(100);  // paramterized with 1 arg
    cout<<"c2::"<<endl;
    c2.display_output(); // real=100 imag=100

    Complex c3(111,222);  //  paramterized with 2 arg
    cout<<"c3::"<<endl;
    c3.display_output(); // real=111 imag=222
 
    int r,c;
    cout<<"Enter value for r=";
    cin>>r;
    cout<<"Enter value for c=";
    cin>>c;
    
    Complex c4(r,c);  //  paramterized with 2 arg
    cout<<"c4::"<<endl;
    c4.display_output(); // real=111 imag=222
    return 0;
}// STACK  FILO / LIFO
// ctor -- c1, c2, c3, c4
// dtor --- c4, c3, c2, c1