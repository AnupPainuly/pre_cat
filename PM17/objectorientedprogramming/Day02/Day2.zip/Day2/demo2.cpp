// structure in cpp 
#include<iostream>
using namespace std;
#pragma pack(1)
class book
{ 
    private:
        // varibale / data members / fields
        int bookid;
        char bookname[10];
        float price;
    // member function / methods
    public:
        void accept_bookinfo()
        {
            cout<<"\n Enter book id::";
            cin>>bookid;
            cout<<"\n Enter book name::";
            cin>>bookname;
            cout<<"\n Enter book price::";
            cin>>price;
            return;
        }
        void dispaly_bookinfo()
        {
            cout<<"\n book no ="<< bookid<<endl;
            cout<<"\n book nane ="<< bookname<<endl;
            cout<<"\n book price ="<<price;
            return;
        }
};

int main()
{
    book b1;//struct book b1;       
    cout<<"\n Enter book info :: \n";
    b1.accept_bookinfo();// accept_bookinfo(&b1);

    cout<<"\n book info using b1 ::\n";
    b1.dispaly_bookinfo();  //dispaly_bookinfo(&b1);

  // b1.price=100; //error as price is private
    cout<<"\n book info using b1 ::\n";
    b1.dispaly_bookinfo();  //dispaly_bookinfo(&b1);

    return 0;
}

/*

book b1, b2;
accept_book_info(&b1); // b1.accept_book_info();
accept_book_info(&b2); // b2.accept_book_info();

dispaly_bookinfo(&b1); // b1.dispaly_bookinfo();
dispaly_bookinfo(&b2); // b2.dispaly_bookinfo();

*/