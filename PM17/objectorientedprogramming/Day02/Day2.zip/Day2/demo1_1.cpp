#include<iostream>
using namespace std;
int main()
{
    // int
    cout<<"int================="<<endl;
    {
        int no1, no2;
        cout<<"Enter no1::";
        cin>>no1;  // allowed
        //cin>>&no1; //error scanf("%d", &no1);
        cout<<"Enter no2::";
        cin>>no2; 
        cout<<"no1="<<no1<<"\t &no1="<<&no1<<endl;
        cout<<"no2="<<no2<<"\t &no2="<<&no2<<"\n";
    }
    // float
    cout<<"float================="<<endl;
    {
        float no1, no2;
        cout<<"Enter no1::";
        cin>>no1;  // allowed
        //cin>>&no1; //error scanf("%d", &no1);
        cout<<"Enter no2::";
        cin>>no2; 
        cout<<"no1="<<no1<<"\t &no1="<<&no1<<endl;
        cout<<"no2="<<no2<<"\t &no2="<<&no2<<"\n";
    }
    // char
    cout<<"char================="<<endl;
    {
        char no1, no2;
        cout<<"Enter no1::";
        cin>>no1;  // allowed
        //cin>>&no1; //error scanf("%d", &no1);
        cout<<"Enter no2::";
        cin>>no2; 
        cout<<"no1="<<no1<<"\t &no1="<<(void*)&no1<<endl;
        cout<<"no2="<<no2<<"\t &no2="<<(void*)&no2<<"\n";
    }
    return 0;
}