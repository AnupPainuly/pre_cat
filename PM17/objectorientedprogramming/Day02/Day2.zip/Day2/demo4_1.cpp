// types of member fun 
// 1. facility of input and output
#include<iostream>
using namespace std;
class Complex
{
    private: // variable/ data member / field
        int real;
        int imag;
    public: // member function/ methods
        //1.1 input
        //void accept_input(Complex * const this)
        void accept_input()
        {
            cout<<"Enter real=";
            cin>>this->real;
            cout<<"Enter imag=";
            cin>>this->imag;
        }
        //1.2 output
        void display_output()
        {
            cout<<"this->real="<<this->real<<"\t["<<&this->real<<"]"<<endl;
            cout<<"this->imag="<<this->imag<<"\t["<<&this->imag<<"]"<<endl;
        }
             
};
// compiler will be default ctor
Complex c2;  // global variable
int main()
{
    Complex c1; // local object
    cout<<"c1::"<<endl;
    c1.display_output(); // garbage value

    cout<<"c2::"<<endl;
    c2.display_output(); // real=0 imag=0

    static Complex c3; // static object
    cout<<"c3::"<<endl;
    c3.display_output(); // real=0 imag=0
    return 0;
}