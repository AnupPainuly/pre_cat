#include<iostream>
using namespace std;
#pragma pack(1)
class Empty
{
};
struct empty
{
};
int main(void)
{
    Empty e1;
    empty e2;
    cout<<"sizeof(e1)="<<sizeof(e1)<<endl;
    cout<<"sizeof(e2)="<<sizeof(e2)<<endl;
    cout<<"sizeof(Empty)="<<sizeof(Empty)<<endl;
    cout<<"sizeof(empty)="<<sizeof(empty)<<endl;
    cout<<"&e1="<<&e1<<endl;
    cout<<"&e2="<<&e2<<endl;
    //cout<<"&Empty="<<&Empty<<endl;  //error
    //cout<<"&empty="<<&empty<<endl;
    return 0;
}

// stack FILO  LIFO
// queue FIFO  LILO 