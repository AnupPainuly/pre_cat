#include<stdio.h>
int main(void)
{
    const float pi=3.142f;
    // error: invalid conversion from ‘const float*’ to ‘float*’ 
    //float *ptr=&pi; error in cpp
    const float *ptr=&pi;

    printf("\n pi=%.2f *ptr=%.2f", pi, *ptr);
    //*ptr=4.4f; //printf("\n pi=%.2f *ptr=%.2f", pi, *ptr);
    printf("\n pi=%.2f *ptr=%.2f", pi, *ptr);

// in cpp prog we can not modify the value of constant variable using pointer
//because if we want to store address of const variable value of pointer must
//be constant
    return 0;
}
