#include<stdio.h>
int no1=10;
int main(void)
{
    int no1=100;
    printf("\n no1=%d [%u] local variable", no1, &no1);
    return 0;
}
