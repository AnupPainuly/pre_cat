// case 2 function overloading
// function having same name but different types of arguments

int sum(int n1, int n2)  // sum@@int,int
{
    return n1+n2;
}
float sum(float n1,  float n2)// sum@@float,float
{
    return n1+n2;
}
#include<stdio.h>
int main(void)
{
    int ans= sum(10,20);
    printf("\n ans=%d", ans);  // ans =30

    float ans1= sum(10.1f,20.2f);
    printf("\n ans1=%.2f", ans1); // ans1=30.3
    
    return 0;
}
// g++ -S demo5_2.cpp