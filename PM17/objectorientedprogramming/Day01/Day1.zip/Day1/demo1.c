// structure in c in main
#include<stdio.h>
#pragma pack(1)
struct book
{
    int bookid;
    char bookname[10];
    float price;
};

int main()
{
    // struct book is user defined data type
    // b1 is variable(object) of user defined data type struct book
    struct book b1={100};   
    struct book *ptr=&b1;

    printf("\n size of b1=%d", sizeof(b1));
    printf("\n size of struct book=%d", sizeof(struct book));

    printf("\n Enter book info :: \n");
    printf("\n Enter book id::");
    scanf("%d", &b1.bookid);
    printf("\n Enter book name::");
    scanf("%s", b1.bookname);
    printf("\n Enter book price::");
    scanf("%f", &b1.price);


    printf("\n book info using b1 ::\n");
    printf("\n book no =%d", b1.bookid);
    printf("\n book nane =%s", b1.bookname);
    printf("\n book price =%.2f", b1.price);
    
    printf("\n book info using pointer(-> operator) ::\n");
    printf("\n book no =%d", ptr->bookid);
    printf("\n book nane =%s", ptr->bookname);
    printf("\n book price =%.2f", ptr->price);
    
    printf("\n &b1=%u &b1+1=%u", &b1,&b1+1);
    printf("\n ptr=%u ptr+1=%u", ptr,ptr+1);
    printf("\n book info using dot (. operator) ::\n");
    printf("\n book no =%d", (*ptr).bookid);
    printf("\n book nane =%s", (*ptr).bookname);
    printf("\n book price =%.2f",(*ptr).price);
    
    return 0;
}