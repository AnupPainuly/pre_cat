// structure in cpp 
#include<stdio.h>
#pragma pack(1)
struct book
{ 
    private:
        // varibale / data members / fields
        int bookid;
        char bookname[10];
        float price;
    // member function / methods
    public:
        void accept_bookinfo()
        {
            printf("\n Enter book id::");
            scanf("%d", &bookid);
            printf("\n Enter book name::");
            scanf("%s", bookname);
            printf("\n Enter book price::");
            scanf("%f", &price);
            return;
        }
        void dispaly_bookinfo()
        {
            printf("\n book no =%d", bookid);
            printf("\n book nane =%s", bookname);
            printf("\n book price =%.2f", price);
            return;
        }
};

int main()
{
    book b1;//struct book b1;       
    printf("\n Enter book info :: \n");
    b1.accept_bookinfo();// accept_bookinfo(&b1);

    printf("\n book info using b1 ::\n");
    b1.dispaly_bookinfo();  //dispaly_bookinfo(&b1);

  // b1.price=100; //error as price is private
    printf("\n book info using b1 ::\n");
    b1.dispaly_bookinfo();  //dispaly_bookinfo(&b1);

    return 0;
}
