#include<stdio.h>
/*int f1(int)  // f1@@int
{
    printf("\ninside int block");
}*/
void f1(int) // f1@@int
{
    printf("\ninside int block");
}
void f1(float)
{
    printf("\ninside float block");
}
void f1(double)
{
    printf("\ninside double block");
}
void f1(char)
{
    printf("\ninside char block");
}
void f1(void)
{
    printf("\ninside void block");
}

void f1(char*)
{
    printf("\ninside char*(string) block");
}

int main(void)
{
    f1(10);   // inside int
    f1(10.2); // inside double
    f1(10.2f); // inside float
    f1(10.2F); // inside float
    f1(); // inside void
    f1('A'); // inside char
    f1("sunbeam"); // inside char*(string)
    f1((int)10.3);// inside int

    return 0;
}