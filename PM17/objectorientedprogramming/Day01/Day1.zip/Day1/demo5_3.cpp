// case 3 function overloading
// function having same name but different order of arguments

float sum(int n1, float n2)  // sum@@int,float
{
    return n1+n2;
}
float sum(float n1,  int n2)// sum@@float,int
{
    return n1+n2;
}
#include<stdio.h>
int main(void)
{
    float ans= sum(10.1f,20);  // sum@@float,int
    printf("\n ans=%.2f", ans);  // ans =30.1

    float ans1= sum(10,20.2f); // sum@@int, float
    printf("\n ans1=%.2f", ans1); // ans1=30.2
    
    return 0;
}
// g++ -S demo5_3.cpp