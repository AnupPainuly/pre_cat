#include<stdio.h>
#define sq(a) a*a
inline int square(int a);
int main(void)
{
    int x=5, y=0;
    
    y= sq(x);  // y= x*x;  // y= 5*5 ;  y=25;
    printf("\n using macro x=%d y=%d", x, y);
    
    y= square(y);
    printf("\n using function x=%d y=%d", x, y);
    return 0;
}
inline int square(int a)
{
    return a*a;
}
//g++ -E -o demo4.i demo4.cpp  cpp

//gcc -E -o demo4.i demo4.c    c prog