// case 1 function overloading
// function having same name but different no of arguments

int sum(int n1, int n2)  // sum@@int,int
{
    return n1+n2;
}
int sum(int n1, int n2, int n3)// sum@@int,int, int
{
    return n1+n2+n3;
}
#include<stdio.h>
int main(void)
{
    int ans= sum(10,20);
    printf("\n ans=%d", ans);  // ans =30

    ans= sum(10,20, 30);
    printf("\n ans=%d", ans); // an60
    
    return 0;
}
// g++ -S demo5_1.cpp