#include<stdio.h>
namespace N1
{
    int no1=30;
    int no2=40;
    namespace N2
    {
        int no1=500;
        int no3=600;
    }
}
int no1=10;
int main(void)
{
    int no1=100;
    printf("\n no1=%d [%u] local variable", no1, &no1);  // no1=10 ;local variable
    printf("\n ::no1=%d [%u] global variable", ::no1, &::no1); // global variable
    // use scope resolution operator to print global variable

    //namespace_name::variable_name;
    printf("\n N1::no1=%d [%u] variablefrom namespace N1", N1::no1, &N1::no1); //  variable no1 =30
    printf("\n N1::no2=%d [%u] variablefrom namespace N1", N1::no2, &N1::no2); //  variable no2 =40
    //outer_namespace_name::inner_namespace_name::variable_name;
    printf("\nN1::N2::no1=%d [%u] variablefrom namespace N1::N2",N1::N2::no1,&N1::N2::no1 );  // no1=500
    printf("\nN1::N2::no3=%d [%u] variablefrom namespace N1::N2",N1::N2::no3,&N1::N2::no3 );  // no1=600
    using namespace N1;
    printf("\n N1::no2=%d [%u] variable from namespace N1", N1::no2, &N1::no2); //  variable no2 =40
    printf("\n no2=%d [%u] variable from namespace N1", no2, &no2); //  variable no2 =40
    printf("\n no1=%d [%u] local variable", no1, &no1);  // no1=10 ;local variable
    printf("\n N1::no1=%d [%u] variablefrom namespace N1", N1::no1, &N1::no1); //  variable no1 =30


  // using namespace N1;
  // using namespace N2;
  //or
  using namespace N1::N2;
  printf("\n no3=%d [%u] variable from N1::N2", no3, &no3);  // no3=600  variable  

    return 0;
}