// structure in c using functions
#include<stdio.h>
#pragma pack(1)
struct book
{
    int bookid;
    char bookname[10];
    float price;
};
void accept_bookinfo(struct book *b); // 4 ot 8 bytes
void dispaly_bookinfo(const struct book *b);//  4 ot 8 bytes
int main()
{
    struct book b1;       
    printf("\n Enter book info :: \n");
    accept_bookinfo(&b1);

    printf("\n book info using b1 ::\n");
    dispaly_bookinfo(&b1);
    b1.price=100;
    printf("\n book info using b1 ::\n");
    dispaly_bookinfo(&b1);
    return 0;
}
void accept_bookinfo(struct book *b)
{
    printf("\n Enter book id::");
    scanf("%d", &b->bookid);
    printf("\n Enter book name::");
    scanf("%s", b->bookname);
    printf("\n Enter book price::");
    scanf("%f", &b->price);
    return;
}
void dispaly_bookinfo(const struct book *b)
{
    //b->price=0;
    printf("\n book no =%d", b->bookid);
    printf("\n book nane =%s", b->bookname);
    printf("\n book price =%.2f", b->price);
    return;
}
// gcc demo2.c  --->  a.exe or a.out  cprog
// g++ demo2.c  --->  a.exe or a.out  cpp