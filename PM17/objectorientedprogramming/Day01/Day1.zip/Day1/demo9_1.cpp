#include<stdio.h>
namespace N1
{
    int no1=30;
    int no2=40;
}
int no1=10;
int main(void)
{
    int no1=100;
    printf("\n no1=%d [%u] local variable", no1, &no1);  // no1=10 ;local variable
    printf("\n ::no1=%d [%u] global variable", ::no1, &::no1); // global variable
    // use scope resolution operator to print global variable

    //namespace_name::variable_name;
    printf("\n N1::no1=%d [%u] variablefrom namespace N1", N1::no1, &N1::no1); //  variable no1 =30
    printf("\n N1::no2=%d [%u] variablefrom namespace N1", N1::no2, &N1::no2); //  variable no2 =40

    using namespace N1;
    printf("\n N1::no2=%d [%u] variable from namespace N1", N1::no2, &N1::no2); //  variable no2 =40
    printf("\n no2=%d [%u] variable from namespace N1", no2, &no2); //  variable no2 =40
    printf("\n no1=%d [%u] local variable", no1, &no1);  // no1=10 ;local variable
    printf("\n N1::no1=%d [%u] variablefrom namespace N1", N1::no1, &N1::no1); //  variable no1 =30


    return 0;
}