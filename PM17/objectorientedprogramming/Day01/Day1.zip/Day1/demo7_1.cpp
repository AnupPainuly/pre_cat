#include<stdio.h>
int sum(int a=0, int b=0, int c=0, int d=0)
{
    printf("\n a=%d b=%d c=%d d=%d", a,b ,c,d);
    return a+b+c+d;
}
int main(void)
{
    int ans=0;
    ans= sum(10,20,30,40);
    printf("\n sum=%d", ans); // 100
    ans= sum(10,20,30);
    printf("\n sum=%d", ans); // 60
    ans= sum(10,20);
    printf("\n sum=%d", ans); // 30
    
    ans= sum(10);
    printf("\n sum=%d", ans); // 10

    ans= sum();
    printf("\n sum=%d", ans); // 0
    
    
    //ans= sum(,10,20,30);
    return 0;

}