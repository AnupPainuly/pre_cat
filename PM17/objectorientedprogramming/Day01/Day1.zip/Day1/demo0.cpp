// struct in c and cpp
// inline fun
// function overloading 
// global variable
// default argrument
// namespace
// class object
// size of empty class

// cin and cout
// types of member function complex class 
