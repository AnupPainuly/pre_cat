//Object_Slicing
#include<iostream>
using namespace std;
namespace NObject_Slicing
{
    class Base
    {
        private:
            int a;
            int b;
        public:
            Base()
            {
                this->a=0;
                this->b=0;
                cout<<"inside parameterless ctor of Base  class"<<endl;
            }
            Base(int a, int b)
            {
                this->a=a;
                this->b=b;
                cout<<"inside parameterized ctor of Base  class"<<endl;
            }
            void print()
            {
                cout<<"inside class Base ::"<<endl;
                cout<<"this->a="<<this->a<<"["<< &this->a<<"]"<<endl;
                cout<<"this->b="<<this->b<<"["<< &this->b<<"]"<<endl;;
            }
            ~Base()
            {
                this->a=0;
                this->b=0;
                cout<<"inside dtor of Base  class"<<endl;
            }

    }; //end of base class

    class Derived: public Base
    {
        private:
            int c;
        public:
           Derived()
           {
               this->c=0;
               cout<<"inside parameterless ctor of Derived  class"<<endl;
           }
           Derived(int a, int b,int c):Base(a,b)
           {
               this->c=c;
                cout<<"inside parameterized ctor of Derived  class"<<endl;
           }
           void print()
           {
                Base ::print();
                cout<<"inside class Derived ::"<<endl;
                cout<<"this->c="<<this->c<<"["<< &this->c<<"]"<<endl;
           }
           ~Derived()
           {
               this->c=0;
               cout<<"inside dtor of Derived  class"<<endl;
           }
    }; // end of class Derived
}// end of namespace 
using namespace NObject_Slicing;
int main(void)
{
    Base obj1;
    cout<<"obj1="<<endl;
    obj1.print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;

    Derived obj2(50, 60, 70);
    cout<<"obj2="<<endl;
    obj2.print();
    cout<<"size of obj2="<<sizeof(obj2)<<endl;

    obj1=obj2;  //  allowed object slicing
    cout<<"obj1="<<endl;
    obj1.print();
    cout<<"size of obj1="<<sizeof(obj1)<<endl;

//    obj2=obj1;  // compile time error
//no operator "=" matches these operands




    return 0;
}