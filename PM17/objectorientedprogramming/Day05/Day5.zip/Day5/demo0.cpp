


// day5

//1. diamond problem
//2. casting upcasting /downcasting
//3. object slicing
//4. virtual function / pure virtual function
//5. function overriding
//6. RTTI
// array class
// shallow copy deep copy 
// copy ctor
// template for function 
// template for class
