// template for array class
#include<iostream>
using namespace std;

template<class Type> // step1 add template above class
class Array
{
    private:
        int size;
        Type *arr; // step 2 change int data type with type
    public:
        Array(int size=5)
        {
            this->size= size;
            this->arr= new Type[this->size];
            // step 3 change int data type with type
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]=0;
            }
            cout<<"inside ctor of array class"<<endl;
        }
        //className(const className& varname)
        Array(const Array&other)
        {
            //&a2       other is new name for a1
            this->size= other.size; // 1 copy size
            // step 4 change int data type with type
            this->arr= new Type[this->size]; // 2 allocate new memory
            int index;
            // step3 copy data
            for(index=0; index<this->size; index++)
            {
                this->arr[index]= other.arr[index];
            }
            cout<<"inside copy ctor of array class"<<endl;
        }
        void accept_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->arr["<<index<<"] ::";
                cin>>this->arr[index];
            }
        }
        void display_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->arr["<<index<<"] \t"<<this->arr[index] <<"\t["<<  &this->arr[index]<<"]"<<endl;
                
            }
        }
        ~Array()
        {
            if(this->arr!=NULL)
            {
                delete [] this->arr;
                this->arr=NULL;
            }
            cout<<"inside dtor of array class"<<endl;
        }

};
int main(void)
{
    Array<int> a1;
    cout<<"a1::"<<endl;
    a1.accept_input();

    cout<<"a1::"<<endl;
    a1.display_input();
   

    Array<float> a2;
    cout<<"a2::"<<endl;
    a2.accept_input();

    cout<<"a2::"<<endl;
    a2.display_input();

    return 0;   
}