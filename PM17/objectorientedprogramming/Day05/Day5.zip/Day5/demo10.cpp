// template
#include<iostream>
using namespace std;
namespace NSwap
{
    template<class Type>
    void swap(Type &n1, Type &n2)
    {
        cout<<"inside my fuc"<<endl;
        Type temp;
        temp=n1;
        n1=n2;
        n2=temp;
        return;
    }
}
int main(void)
{
    {
        cout<<"int data type"<<endl;
        int no1=10,no2=20;
        cout<<"before swap no1="<<no1<<"\t no2="<<no2<<endl;
        NSwap::swap(no1, no2);
        cout<<"after swap no1="<<no1<<"\t no2="<<no2<<endl;
    }
    cout<<"=-------------------------------------"<<endl;

    {
        cout<<"float data type"<<endl;
        float no1=10.2,no2=20.3;
        cout<<"before swap no1="<<no1<<"\t no2="<<no2<<endl;
        NSwap::swap(no1, no2);
        cout<<"after swap no1="<<no1<<"\t no2="<<no2<<endl;
    }
    cout<<"=-------------------------------------"<<endl;
    {
        cout<<"char data type"<<endl;
        char no1='A',no2='B';
        cout<<"before swap no1="<<no1<<"\t no2="<<no2<<endl;
        NSwap::swap(no1, no2);
        cout<<"after swap no1="<<no1<<"\t no2="<<no2<<endl;
    }
    cout<<"=-------------------------------------"<<endl;
    return 0;
}
