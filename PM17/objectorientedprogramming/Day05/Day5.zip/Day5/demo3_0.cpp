//Diamond Problem Sol1
#include<iostream>
using namespace std;
namespace NDiamondProblemSol1
{
    class A
    {
        public:
            int a;
        A()
        {
            this->a=10;
            cout<<"inside parameterless ctor of Class A"<<endl;
        }
        A(int a)
        {
            this->a=a;
            cout<<"inside parameterized ctor of Class A"<<endl;
        }
        void print()
        {
            cout<<"inside class A::"<<endl;
            cout<<"this->a="<<this->a<<"\t["<< &this->a<<"]"<<endl;
        }
        ~A()
        {
            this->a=0;
            cout<<"inside dtor of Class A"<<endl;
        }

    }; //end of class A

    class B: public A
    {
        public:
            int b;
        B()
        {
            this->b=20;
            cout<<"inside parameterless ctor of Class B"<<endl;
        }
        B(int a, int b):A(a)
        {
            this->b=b;
            cout<<"inside parameterized ctor of Class B"<<endl;
        }
        void print()
        {
            A::print();
            cout<<"inside class B::"<<endl;
            cout<<"this->a="<<this->a<<"\t["<< &this->a<<"]"<<endl;
            cout<<"this->b="<<this->b<<"\t["<< &this->b<<"]"<<endl;
        }
        ~B()
        {
            this->b=0;
            cout<<"inside dtor of Class B"<<endl;
        }

    }; //end of class B

    class C: public A
    {
        public:
            int c;
        C()
        {
            this->c=30;
            cout<<"inside parameterless ctor of Class C"<<endl;
        }
        C(int a, int c):A(a)
        {
            this->c=c;
            cout<<"inside parameterized ctor of Class C"<<endl;
        }
        void print()
        {
            A::print();
            cout<<"inside class C::"<<endl;
            cout<<"this->a="<<this->a<<"\t["<< &this->a<<"]"<<endl;
            cout<<"this->c="<<this->c<<"\t["<< &this->c<<"]"<<endl;
        }
        ~C()
        {
            this->c=0;
            cout<<"inside dtor of Class C"<<endl;
        }

    }; //end of class C

    //class D: public B, public C
    class D: public C, public B
    {
        public:
            int d;
        D()
        {
            this->d=40;
            cout<<"inside parameterless ctor of Class D"<<endl;
        }
        D(int a, int b , int c, int d):B(a,b), C(a,c)
        {
            this->d=d;
            cout<<"inside parameterized ctor of Class D"<<endl;
        }
        void print()
        {
            B::print();
            C::print();
            cout<<"inside class D::"<<endl;
            //"NDiamondProblemSol1::D::a" is ambiguous
//           cout<<"this->a="<<this->a<<"\t["<< &this->a<<"]"<<endl;
            // sol no1 for diamond problem
             cout<<"this->B::a= via class B "<<this->B::a<<"\t["<< &this->B::a<<"]"<<endl;
             cout<<"this->C::a= via class C "<<this->C::a<<"\t["<< &this->C::a<<"]"<<endl;
            cout<<"this->c="<<this->b<<"\t["<< &this->b<<"]"<<endl;
            cout<<"this->c="<<this->c<<"\t["<< &this->c<<"]"<<endl;
            cout<<"this->d="<<this->d<<"\t["<< &this->d<<"]"<<endl;
        }
        ~D()
        {
            this->d=0;
            cout<<"inside dtor of Class D"<<endl;
        }

    }; //end of class D

}// end of namespace 
using namespace NDiamondProblemSol1;
int main(void)
{
  /*
    A obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
    cout<<"obj1.a in main="<<obj1.a<<endl;

    A obj2(111);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
    cout<<"obj2.a in main ="<<obj2.a<<endl;       
*/
/*
    B obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
    cout<<"obj1.a in main="<<obj1.a<<endl;
    cout<<"obj1.b in main="<<obj1.b<<endl;

    B obj2(111,222);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
    cout<<"obj2.a in main ="<<obj2.a<<endl;       
    cout<<"obj2.b in main ="<<obj2.b<<endl;       
*/
/*
    C obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
    cout<<"obj1.a in main="<<obj1.a<<endl;
    cout<<"obj1.c in main="<<obj1.c<<endl;

    C obj2(111,333);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
    cout<<"obj2.a in main ="<<obj2.a<<endl;       
    cout<<"obj2.c in main ="<<obj2.c<<endl;       
*/

  D obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
    //cout<<"obj1.a in main="<<obj1.a<<endl; // error
    cout<<"obj1.B::a in main via class B="<<obj1.B::a<<endl;
    cout<<"obj1.C::a in main via class C="<<obj1.C::a<<endl;
    cout<<"obj1.b in main="<<obj1.b<<endl;
    cout<<"obj1.c in main="<<obj1.c<<endl;
    cout<<"obj1.d in main="<<obj1.d<<endl;

    D obj2(111,222,333, 444);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
    //cout<<"obj2.a in main="<<obj2.a<<endl; // error
    cout<<"obj2.B::a in main via class B="<<obj2.B::a<<endl;
    cout<<"obj2.C::a in main via class C="<<obj2.C::a<<endl;
    cout<<"obj2.b in main="<<obj2.b<<endl;
    cout<<"obj2.c in main="<<obj2.c<<endl;
    cout<<"obj2.d in main="<<obj2.d<<endl;

    return 0;
}
