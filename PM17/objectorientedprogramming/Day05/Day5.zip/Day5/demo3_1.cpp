// DiamondProblemSol 2  virtual inheritance
#pragma pack(1)
#include<iostream>
using namespace std;
namespace NDiamondProblemSol2
{
    class A
    {
        private:
            int a;
        public:
            A()
            {
                this->a=10;
                cout<<"inside parameterless ctor of Class A"<<endl;
            }
            A(int a)
            {
                this->a=a;
                cout<<"inside parameterized ctor of Class A"<<endl;
            }
            void print()
            {
                cout<<"inside class A::"<<endl;
                cout<<"this->a="<<this->a<<"\t["<< &this->a<<"]"<<endl;
            }
            ~A()
            {
                this->a=0;
                cout<<"inside dtor of Class A"<<endl;
            }

        }; //end of class A

    class B: virtual public A
    {
        private:
            int b;
        public:
        B()
        {
            this->b=20;
            cout<<"inside parameterless ctor of Class B"<<endl;
        }
        B(int a, int b):A(a)
        {
            this->b=b;
            cout<<"inside parameterized ctor of Class B"<<endl;
        }
        void print()
        {
            A::print();
            cout<<"inside class B::"<<endl;
            cout<<"this->b="<<this->b<<"\t["<< &this->b<<"]"<<endl;
        }
        void onlyBprint()
        {
            cout<<"inside class B::"<<endl;
            cout<<"this->b="<<this->b<<"\t["<< &this->b<<"]"<<endl;
        }
        ~B()
        {
            this->b=0;
            cout<<"inside dtor of Class B"<<endl;
        }

    }; //end of class B

    class C: virtual public A
    {
        private:
            int c;
        public:
        C()
        {
            this->c=30;
            cout<<"inside parameterless ctor of Class C"<<endl;
        }
        C(int a, int c):A(a)
        {
            this->c=c;
            cout<<"inside parameterized ctor of Class C"<<endl;
        }
        void print()
        {
            A::print();
            cout<<"inside class C::"<<endl;
            cout<<"this->c="<<this->c<<"\t["<< &this->c<<"]"<<endl;
        }
        void onlyCprint()
        {
            cout<<"inside class C::"<<endl;
            cout<<"this->c="<<this->c<<"\t["<< &this->c<<"]"<<endl;
        }
        ~C()
        {
            this->c=0;
            cout<<"inside dtor of Class C"<<endl;
        }

    }; //end of class C

    class D: public B, public C
    //class D: public C, public B
    {
        private:
            int d;
        public:
        D()
        {
            this->d=40;
            cout<<"inside parameterless ctor of Class D"<<endl;
        }
        D(int a, int b , int c, int d):B(a,b), C(a,c), A(a)
        {
            this->d=d;
            cout<<"inside parameterized ctor of Class D"<<endl;
        }
        void print()
        {
            A::print();
            B::onlyBprint();
            C::onlyCprint();
            cout<<"inside class D::"<<endl;
  
           cout<<"this->d="<<this->d<<"\t["<< &this->d<<"]"<<endl;
        }
        ~D()
        {
            this->d=0;
            cout<<"inside dtor of Class D"<<endl;
        }

    }; //end of class D

}// end of namespace 
using namespace NDiamondProblemSol2;
int main(void)
{
  
  /*  A obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
   

    A obj2(111);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
   
*/
/*
    B obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl; // 4+4+8=16
   
    B obj2(111,222);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
   
*/
/*
    C obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
   
    C obj2(111,333);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
   
*/

  D obj1;
    cout<<" obj1 ::"<<endl;
    obj1.print();
    cout<<"sizeof obj1 ="<<sizeof(obj1)<<endl;
   
    D obj2(111,222,333, 444);
    cout<<" obj2 ::"<<endl;
    obj2.print();
    cout<<"sizeof obj2 ="<<sizeof(obj2)<<endl;
   

    return 0;
}

// 9881144174
// rahul@sunbeaminfo.com

