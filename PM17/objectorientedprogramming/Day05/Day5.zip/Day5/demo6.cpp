// virtual functions
#include<iostream>
using namespace std;
namespace NCasting
{
    class Base
    {
        private:
            int a;
            int b;
        public:
            Base()
            {
                this->a=0;
                this->b=0;
                cout<<"inside parameterless ctor of Base  class"<<endl;
            }
            Base(int a, int b)
            {
                this->a=a;
                this->b=b;
                cout<<"inside parameterized ctor of Base  class"<<endl;
            }
            virtual void print()
            {
                cout<<"inside class Base ::"<<endl;
                cout<<"this->a="<<this->a<<"["<< &this->a<<"]"<<endl;
                cout<<"this->b="<<this->b<<"["<< &this->b<<"]"<<endl;;
            }
            ~Base()
            {
                this->a=0;
                this->b=0;
                cout<<"inside dtor of Base  class"<<endl;
            }

    }; //end of base class

    class Derived: public Base
    {
        private:
            int c;
        public:
           Derived()
           {
               this->c=0;
               cout<<"inside parameterless ctor of Derived  class"<<endl;
           }
           Derived(int a, int b,int c):Base(a,b)
           {
               this->c=c;
                cout<<"inside parameterized ctor of Derived  class"<<endl;
           }
           void print()
           {
                Base ::print();
                cout<<"inside class Derived ::"<<endl;
                cout<<"this->c="<<this->c<<"["<< &this->c<<"]"<<endl;
           }
           ~Derived()
           {
               this->c=0;
               cout<<"inside dtor of Derived  class"<<endl;
           }
    }; // end of class Derived
}// end of namespace 
using namespace NCasting;
int main(void)
{
    Base *ptrbase1=new Derived; // upcasting
    cout<<"ptrbase1::";
    ptrbase1->print(); // derived class method
    delete ptrbase1;
    ptrbase1=NULL;

    Base *ptrbase2=NULL;
    Derived objDerived;
    ptrbase2= &objDerived; // upcasting
    cout<<"ptrbase2::";
    ptrbase2->print(); // derived class method

    //Derived *ptrderived= new Base;  //error downcasting 

    Derived *ptrderived2=NULL;
        Base ObjBase;
    //ptrderived2=&ObjBase; // erorr downcasting

    return 0;
}
