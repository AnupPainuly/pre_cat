// use of array class for deep copy
#include<iostream>
using namespace std;

class Array
{
    private:
        int size;
        int *arr;
    public:
        Array(int size=5)
        {
            this->size= size;
            this->arr= new int[this->size];
            int index;
            for(index=0; index<this->size; index++)
            {
                this->arr[index]=0;
            }
            cout<<"inside ctor of array class"<<endl;
        }
        //className(const className& varname)
        Array(const Array&other)
        {
            //&a2       other is new name for a1
            this->size= other.size; // 1 copy size
            this->arr= new int[this->size]; // 2 allocate new memory
            int index;
            // step3 copy data
            for(index=0; index<this->size; index++)
            {
                this->arr[index]= other.arr[index];
            }
            cout<<"inside copy ctor of array class"<<endl;
        }
        void accept_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->arr["<<index<<"] ::";
                cin>>this->arr[index];
            }
        }
        void display_input()
        {
            int index;
            for(index=0; index<this->size; index++)
            {
                cout<<"this->arr["<<index<<"] \t"<<this->arr[index] <<"\t["<<  &this->arr[index]<<"]"<<endl;
                
            }
        }
        ~Array()
        {
            if(this->arr!=NULL)
            {
                delete [] this->arr;
                this->arr=NULL;
            }
            cout<<"inside dtor of array class"<<endl;
        }

};
int main(void)
{
    Array a1;
    cout<<"a1::"<<endl;
    a1.accept_input();

    cout<<"a1::"<<endl;
    a1.display_input();

    // if we assign allready created object(a1) to new created object (a2)
    // internally copy ctor gets called for a2 object
    Array a2=a1;  //  Array a2(a1);
    cout<<"a2::"<<endl;
    a2.display_input();

    {
    // if we assign allready created object(a3) to all created object (a4)
    // internally assignment operator function gets called for a4 object
    Array a3;
    Array a4;

    a4=a3;

    }

    return 0;   
}