// composition
#pragma pack(1)
#include<cstring>  // #include<string.h>

#include<iostream>
using namespace std;
namespace NComposition
{
    class Date
    {
        private:
            int dd;
            int mm;
            int yy;
        public:
            Date()
            {
                this->dd=10;
                this->mm=5;
                this->yy=2000;
                cout<<"inside parameterless ctor of Date class"<<endl;
            }
            Date(int dd, int mm, int yy)
            {
                this->dd=dd;
                this->mm=mm;
                this->yy=yy;
                cout<<"inside parameterized ctor of Date class"<<endl;
            }
            void print()
            {
                cout<<"date::"<<endl;
                cout<<this->dd<<"/"<<this->mm<<"/"<<this->yy<<endl;
            }
            ~Date()
            {
                this->dd=0;
                this->mm=0;
                this->yy=0;
                cout<<"inside dtor of Date class"<<endl;
            }
            

    };// end of date class

     class Address
    {
        private:
            char addressinfo[20];
            char city[16];
            int pincode;
        public:
            Address()
            {
                strcpy(this->addressinfo, "Market Yard");
                strcpy(this->city, "Pune");
                this->pincode=411037;
                cout<<"inside parameterless ctor of Address class"<<endl;
            }
            Address(char *addressinfo, char* city, int pincode)
            {
                strcpy(this->addressinfo, addressinfo);
                strcpy(this->city, city);
                this->pincode=pincode;
                cout<<"inside parameterized ctor of Address class"<<endl;
            }
            void print()
            {
                cout<<"address::"<<endl;
                cout<<" address info :: "<<this->addressinfo<<endl;
                cout<<" city :: "<<this->city<<endl;
                cout<<" printcode :: "<<this->pincode<<endl;

            }
            ~Address()
            {
                strcpy(this->addressinfo, "");
                strcpy(this->city, "");
                this->pincode=0;
                cout<<"inside dtor of Address class"<<endl;
            }
    };  // end of Address class

    class Person
    {
        private:
            char name[20];     // 20
            Address per_address; //40
            Date dob;          // 12 
        public:
            Person()
            {
                strcpy(this->name,"abc");
                cout<<"inside parameterless ctor of Person class"<<endl;
            }
            Person(char *name)
            {
                strcpy(this->name,name);
                cout<<"inside parameterized ctor of Person class"<<endl;
            }
            // ctor init list
            Person(char *name,char *addressinfo, char* city, int pincode, int dd, int mm, int yy):per_address(addressinfo,city,pincode), dob(dd, mm, yy)
            {
                strcpy(this->name,name);
                cout<<"inside parameterized ctor of Person class"<<endl;
            }
            void  print_person_info()
            {
                cout<<"person name ::"<<this->name<<endl;
                //this->obejctname.methodname();
                this->dob.print();
                this->per_address.print();
            }
            ~Person()
            {
                strcpy(this->name,"");
                cout<<"inside dtor of Person class"<<endl;
            }

    }; // end of person class 

}//end of namespace 
using namespace NComposition;
int main(void)
{
    Person p1;   //NComposition::Person a1;
    cout<<"p1="<<endl;  // parameterless
    p1.print_person_info();
    cout<<"sizeof p1="<<sizeof(p1)<<endl;  // 20+12+40 ==72

    Person p2("xyz","hinjewadi It park","pune", 411001,11,2,2000);   //NComposition::Person a1;
  // Person p2("xyz");
    cout<<"p2="<<endl;  // parameterless
    p2.print_person_info();
    cout<<"sizeof p2="<<sizeof(p2)<<endl;  // 20+12+40 ==72


    return 0;
}