// composition
#pragma pack(1)
#include<cstring>  // #include<string.h>

#include<iostream>
using namespace std;
namespace NInheritance
{
    class Date
    {
        private:
            int dd;
            int mm;
            int yy;
        public:
            Date()
            {
                this->dd=10;
                this->mm=5;
                this->yy=2000;
                cout<<"inside parameterless ctor of Date class"<<endl;
            }
            Date(int dd, int mm, int yy)
            {
                this->dd=dd;
                this->mm=mm;
                this->yy=yy;
                cout<<"inside parameterized ctor of Date class"<<endl;
            }
            void print()
            {
                cout<<"date::"<<endl;
                cout<<this->dd<<"/"<<this->mm<<"/"<<this->yy<<endl;
            }
            ~Date()
            {
                this->dd=0;
                this->mm=0;
                this->yy=0;
                cout<<"inside dtor of Date class"<<endl;
            }
            

    };// end of date class

     class Address
    {
        private:
            char addressinfo[20];
            char city[16];
            int pincode;
        public:
            Address()
            {
                strcpy(this->addressinfo, "Market Yard");
                strcpy(this->city, "Pune");
                this->pincode=411037;
                cout<<"inside parameterless ctor of Address class"<<endl;
            }
            Address(char *addressinfo, char* city, int pincode)
            {
                strcpy(this->addressinfo, addressinfo);
                strcpy(this->city, city);
                this->pincode=pincode;
                cout<<"inside parameterized ctor of Address class"<<endl;
            }
            void print()
            {
                cout<<"address::"<<endl;
                cout<<" address info :: "<<this->addressinfo<<endl;
                cout<<" city :: "<<this->city<<endl;
                cout<<" printcode :: "<<this->pincode<<endl;

            }
            ~Address()
            {
                strcpy(this->addressinfo, "");
                strcpy(this->city, "");
                this->pincode=0;
                cout<<"inside dtor of Address class"<<endl;
            }
    };  // end of Address class

    class Person
    {
        private:
            char name[20];     // 20
            Address per_address; //40
            Date dob;          // 12 
        public:
            Person()
            {
                strcpy(this->name,"abc");
                cout<<"inside parameterless ctor of Person(Base) class"<<endl;
            }
            Person(char *name)
            {
                strcpy(this->name,name);
                cout<<"inside parameterized ctor of Person(Base) class"<<endl;
            }
            // ctor init list
            Person(char *name,char *addressinfo, char* city, int pincode, int dd, int mm, int yy):per_address(addressinfo,city,pincode), dob(dd, mm, yy)
            {
                strcpy(this->name,name);
                cout<<"inside parameterized ctor of Person(Base) class"<<endl;
            }
            void  print_person_info()
            {
                cout<<"person name ::"<<this->name<<endl;
                //this->obejctname.methodname(); use in composition
                this->dob.print();
                this->per_address.print();
            }
            ~Person()
            {
                strcpy(this->name,"");
                cout<<"inside dtor of Person (base)class"<<endl;
            }

    }; // end of person class 
    //    Derived           Base
    class Employee: public Person
    {
        private:
            int empno;
            char designation[20];
            float sal;
            static int counter;
        public:
            Employee()
            {
                Employee::counter++;
                this->empno= Employee::counter;
                strcpy(this->designation,"S/W dev");
                this->sal=10000;
                cout<<"inside parameterless ctor of Employee(derived) class"<<endl;
            }
            Employee(char *desigination, float sal,char *name,char *addressinfo, char* city, int pincode, int dd, int mm, int yy ):Person(name,addressinfo, city,  pincode, dd, mm, yy)
            {
                Employee::counter++;
                this->empno= Employee::counter;
                strcpy(this->designation,desigination);
                this->sal=sal;
                cout<<"inside parameterized ctor of Employee(derived) class"<<endl;
            }

            void print_emp_info()
            {
                cout<<" empno="<<this->empno<<endl;
                cout<<" designation="<<this->designation<<endl;
                cout<<" sal="<<this->sal<<endl;
                //BaseClassName::MethodName
                Person::print_person_info();

            }
            ~Employee()
            {
                this->empno=0;
                strcpy(this->designation,"");
                this->sal=0;
                cout<<"inside dtor of Employee(derived) class"<<endl;
            }


    };// end of employee class
    int Employee::counter=1000;
    // global defination  for static data member

}//end of namespace 
using namespace NInheritance;
int main(void)
{
    Employee e1;   //NInheritance::Employee a1;
    cout<<"e1="<<endl;  // parameterless
    e1.print_emp_info();
    cout<<"sizeof e1="<<sizeof(e1)<<endl;  // 20+12+40 ==72 + 4+20+4=100

    Employee e2("s/w testing", 9000,"xyz","hinjewadi It park","pune", 411001,11,2,2000);   //NComposition::Person a1;
  
    cout<<"e2="<<endl;  // parameterized
    e2.print_emp_info();
    cout<<"sizeof (e2)="<<sizeof(e2)<<endl;  // 20+12+40 ==72+28=100


    return 0;
}