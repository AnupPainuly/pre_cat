

//day4
// operator overloading 
// OPPS concepts
// composition 
	// demo of person
            // date class
            // address class
            //person class				
// inheritance
	// demo of employee class
//       types of inherittnace
//       modes of inherittnace


