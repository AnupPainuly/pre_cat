// composition
#pragma pack(1)
#include<iostream>
using namespace std;
namespace NComposition
{
    class Date
    {
        private:
            int dd;
            int mm;
            int yy;
        public:
            Date()
            {
                this->dd=10;
                this->mm=5;
                this->yy=2000;
                cout<<"inside parameterless ctor of Date class"<<endl;
            }
            Date(int dd, int mm, int yy)
            {
                this->dd=dd;
                this->mm=mm;
                this->yy=yy;
                cout<<"inside parameterized ctor of Date class"<<endl;
            }
            void print()
            {
                cout<<"date::"<<endl;
                cout<<this->dd<<"/"<<this->mm<<"/"<<this->yy<<endl;
            }
            ~Date()
            {
                this->dd=0;
                this->mm=0;
                this->yy=0;
                cout<<"inside dtor of Date class"<<endl;
            }
            

    };// end of date class
    

}//end of namespace 
using namespace NComposition;
int main(void)
{
    Date d1;   //NComposition::Date d1;
    cout<<"d1="<<endl;  // parameterless
    d1.print();
    cout<<"sizeof d1="<<sizeof(d1)<<endl;

    Date d2(11,2,2000);   //
    cout<<"d2="<<endl;  // parameterized ctor
    d2.print();
    cout<<"sizeof d2="<<sizeof(d2)<<endl;

    return 0;
}

