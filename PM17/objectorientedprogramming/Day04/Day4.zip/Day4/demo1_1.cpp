// composition
#pragma pack(1)

#include<iostream>
#include<cstring>  // #include<string.h>
using namespace std;
namespace NComposition
{
    class Address
    {
        private:
            char addressinfo[20];
            char city[16];
            int pincode;
        public:
            Address()
            {
                strcpy(this->addressinfo, "Market Yard");
                strcpy(this->city, "Pune");
                this->pincode=411037;
                cout<<"inside parameterless ctor of Address class"<<endl;
            }
            Address(char *addressinfo, char* city, int pincode)
            {
                strcpy(this->addressinfo, addressinfo);
                strcpy(this->city, city);
                this->pincode=pincode;
                cout<<"inside parameterized ctor of Address class"<<endl;
            }
            void print()
            {
                cout<<"address::"<<endl;
                cout<<" address info :: "<<this->addressinfo<<endl;
                cout<<" city :: "<<this->city<<endl;
                cout<<" printcode :: "<<this->pincode<<endl;

            }
            ~Address()
            {
                strcpy(this->addressinfo, "");
                strcpy(this->city, "");
                this->pincode=0;
                cout<<"inside dtor of Address class"<<endl;
            }
    };  // end of Address class
} // end of namespace

using namespace NComposition;
int main(void)
{
    Address a1;   //NComposition::Address d1;
    cout<<"a1="<<endl;  // parameterless
    a1.print();
    cout<<"sizeof a1="<<sizeof(a1)<<endl;

    Address a2("hinjewadi It park","pune", 411001 );   //
    cout<<"a2="<<endl;  // parameterized ctor
    a2.print();
    cout<<"sizeof a2="<<sizeof(a2)<<endl;

    return 0;
}