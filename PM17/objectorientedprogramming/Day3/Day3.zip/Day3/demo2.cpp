#include<iostream>
using namespace std;

int main(void)
{
    int a=10;
    int &r=a; // r is a reference of a
 // int *const r=&a;

    cout<<"a="<<a<<"\t&a="<<&a<<endl;
    cout<<"r="<<r<<"\t&r="<<&a<<endl;

    a=100;
    cout<<"a="<<a<<"\t&a="<<&a<<endl;
    cout<<"r="<<r<<"\t&r="<<&a<<endl;

    r=1000;
    cout<<"a="<<a<<"\t&a="<<&a<<endl;
    cout<<"r="<<r<<"\t&r="<<&a<<endl;

    a++;
    cout<<"a="<<a<<"\t&a="<<&a<<endl;
    cout<<"r="<<r<<"\t&r="<<&a<<endl;

    r++;
    cout<<"a="<<a<<"\t&a="<<&a<<endl;
    cout<<"r="<<r<<"\t&r="<<&a<<endl;
    {
       // int &r1=NULL;  //error

        //int &r1=100;
        // we can not create reference to constants
        
        // we can create reference to obejct/variables
        int a1=100;
        int &r1=a1;
        // int * const r1=&a1;

    }


    return 0;
}
/*
int no=100;
int *ptr=NULL;               int a=10;
ptr=&no;
ptr=&no2;
or                           int &r=a;  /// allowed 
int no1=10;                  int &r1;
int *ptr=&no1;               r1=a; // error
ptr=&no2;
*ptr                         r=10   a=10    
*/