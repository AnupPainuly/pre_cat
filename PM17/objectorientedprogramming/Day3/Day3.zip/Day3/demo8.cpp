// demo of static data member
#include<iostream>
using namespace std;

class Static_Demo
{
    private:
        int id;
        int a;
        int b;
        static int counter;
    public:
        Static_Demo()
        {
            Static_Demo::counter++;
            this->id=Static_Demo::counter;
            this->a=10;
            this->b=20;
        }
        Static_Demo(int a, int b)
        {
            Static_Demo::counter++;
            this->id=Static_Demo::counter;
            this->a=a;
            this->b=b;
        }
        void print()
        {
            cout<<"this->id="<<this->id<<"["<< &this->id<<"]"<<endl;
            cout<<"this->a="<<this->a<<"["<< &this->a<<"]"<<endl;
            cout<<"this->b="<<this->b<<"["<< &this->b<<"]"<<endl;
            cout<<"Static_Demo::counter="<<Static_Demo::counter<<"["<< &Static_Demo::counter<<"]"<<endl;
        }
        
        ~Static_Demo()
        {
            this->id=0;
            this->a=0;
            this->b=0;
        }
};
// we have to write global defination for static data member
//int Static_Demo::counter;  // default value of static is zero
int Static_Demo::counter=1000;  

int main()
{
    Static_Demo s1(11,22);
    cout<<"s1="<<endl;
    s1.print(); // counter=1001 id=1001 a=11, b=12
    cout<<"size of s1="<<sizeof(s1)<<endl;


    Static_Demo s2(33,44);
    cout<<"s2="<<endl;
    s2.print();// counter=1002 id=1002 a=33, b=44
    cout<<"size of s2="<<sizeof(s2)<<endl;


    Static_Demo s3(55,66), s4(77,88);
    cout<<"s3="<<endl;
    s3.print();// counter=1004 id=1003 a=55, b=66
    cout<<"size of s3="<<sizeof(s3)<<endl;
    cout<<"s4="<<endl;
    s4.print();// counter=1004 id=1004 a=77, b=88
    cout<<"size of s4="<<sizeof(s4)<<endl;
    return 0;
}