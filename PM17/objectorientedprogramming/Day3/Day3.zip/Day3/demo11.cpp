/// way2 operator overloading using member function


#include<iostream>
using namespace std;
class Complex
{
    private: // variable/ data member / field
        int real;
        int imag;
    public: // member function/ methods
        //1.1 input
        //void accept_input(Complex * const this)
        void accept_input()
        {
            cout<<"Enter real=";
            cin>>this->real;
            cout<<"Enter imag=";
            cin>>this->imag;
        }
        //1.2 output
        void display_output()
        {
            cout<<"this->real="<<this->real<<"\t["<<&this->real<<"]"<<endl;
            cout<<"this->imag="<<this->imag<<"\t["<<&this->imag<<"]"<<endl;
        }
        // 2.1  parameterless ctor or no argument ctor
        // Complex(Complex * const this)
        Complex()
        {
            this->real=10;
            this->imag=20;
 
        }
        // 2.2  parameterized ctor with one argrments
        // Complex(Complex * const this, int value)
        Complex(int value)
        {
            this->real=value;
            this->imag=value;
 
        }
      // 2.3  parameterized ctor with two argrments
      // Complex(Complex * const this, int real, int imag)
        Complex(int real, int imag)
        {
            this->real=real;
            this->imag=imag;
 
        }

        // 3. dtor
        ~Complex()
        {
            this->real=0;
            this->imag=0;
 
        }

        //Complex C3= sum(c1, c2);
        //Complex C4= c1.minus( c2);
        Complex Minus(Complex other1)
        {
            Complex temp;
            temp.real= this->real - other1.real;
            temp.imag= this->imag - other1.imag;
            return temp;
        }
        Complex operator-(Complex other1)
        {
            Complex temp;
            temp.real= this->real - other1.real;
            temp.imag= this->imag - other1.imag;
            return temp;
        }
  
};

int main()
{
    Complex c1(10,20), c2(30,40);
    cout<<"C1="<<endl;
    c1.display_output();  // 10 20
    cout<<"C2="<<endl;
    c2.display_output();  // 30 40

    Complex c3= c1.Minus(c2);
    cout<<"C3="<<endl;
    c3.display_output();  // -20 -20

    Complex c4= c1-c2;
    //Complex c4= c1.operator-(c2);
    cout<<"C3="<<endl;
    c3.display_output();  // -20 -20

    return 0;
}