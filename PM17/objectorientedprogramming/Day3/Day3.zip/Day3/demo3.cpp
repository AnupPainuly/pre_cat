#include<iostream>
using namespace std;
class demo
{
    private:
        int &r1;
        char &r2;
};
int main()
{
    cout<<"size of demo="<<sizeof(demo)<<endl;
    return 0;
}