#include<iostream>
using namespace std;
int main()
{
    int no1, no2, ans;

    cout<<"Enter No1=";
    cin>>no1;
    
    cout<<"Enter No2=";
    cin>>no2;

    try
    {
        if(no2==0)
          throw 1;
               // throw 'A';
           //throw 11.1f; // float
              //throw 1.1;  
            //throw __LINE__+1;  // int
        ans= no1/no2;
        cout<<"ans="<<ans<<endl;
    }
  
    catch(int no)
    {
        cout<<"inside int block1"<<endl;
        cout<<"can not divide by zero error by line no ="<<no<<endl;
        cout<<"file name ="<<__FILE__<<endl;
        cout<<"Date ="<<__DATE__<<endl;
        cout<<"Time ="<<__TIME__<<endl;
    }
    catch(int no)
    {
        cout<<"inside int block2"<<endl;
        cout<<"can not divide by zero error by line no ="<<no<<endl;        
    }
    catch(float no)
    {
        cout<<"inside float block"<<endl;
        cout<<"can not divide by zero error by line no ="<<no<<endl;
    }   
    catch(double no)
    {
        cout<<"inside double block"<<endl;
        cout<<"can not divide by zero error by line  ="<<endl;
    }   
    catch(...)
    {
        cout<<"inside generic catch"<<endl;
        cout<<"can not divide by zero error "<<endl;
    }  
    return 0;       
}