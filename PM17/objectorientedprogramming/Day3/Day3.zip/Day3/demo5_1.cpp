// allocate memory for single variable of char type
#include<iostream>
using namespace std;
int main(void)
{
    char *ptr=NULL;
    //ptr= new char;
    ptr= new char('A');
    cout<<"*ptr="<<*ptr<<endl;


    *ptr='B';
    cout<<"*ptr="<<*ptr<<endl;

    cout<<"enter *ptr=";
    cin>>*ptr;  // scanf("%d", ptr);
    cout<<"*ptr="<<*ptr<<endl;

    //delete ptr;
    //ptr=NULL;
    cout<<"memory is freed"<<endl;


    return 0;
}
