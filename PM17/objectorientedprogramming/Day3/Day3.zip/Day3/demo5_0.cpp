/*
int *ptr=NULL;
ptr= (int*)malloc(1*sizeof(int));
free(ptr);
ptr=NULL; or ptr=0;

ptr= new int;
delete ptr;
ptr=NULL; or ptr=0;

valgrind is tool to check memory leakage on linux/ mac
*/
// allocate memory for single variable of int type
#include<iostream>
using namespace std;
int main(void)
{
    int *ptr=NULL;
    //ptr= new int;
    ptr= new int(111);
    cout<<"*ptr="<<*ptr<<endl;


    *ptr=500;
    cout<<"*ptr="<<*ptr<<endl;

    cout<<"enter *ptr=";
    cin>>*ptr;  // scanf("%d", ptr);
    cout<<"*ptr="<<*ptr<<endl;

    delete ptr;
    ptr=NULL;
    cout<<"memory is freed"<<endl;


    return 0;
}
// g++ demo5_0.cpp ---> a.out
// valgrind ./a.out 