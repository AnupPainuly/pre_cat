// allocate memory for an array using new operator
#include<iostream>
using namespace std;
int main(void)
{
    int *ptr=NULL, index, no;

    cout<<"enter how many elements u want ::";
    cin>>no;

    //ptr= (int*)malloc(no*sizeof(int));
    ptr= new int[no];

    cout<<"enter elements of array ::"<<endl;
    for(index=0; index<no; index++)
    {
        cout<<"ptr["<<index<<"]=";
        cin>>ptr[index];
    }

    cout<<"elements of array ::"<<endl;
    for(index=0; index<no; index++)
    {
        cout<<"ptr["<<index<<"]" << ptr[index] <<"["<< &ptr[index] <<" ]"<<endl;;
    }

    delete [] ptr;
    ptr=NULL;
    cout<<"memory is freed"<<endl;
    return 0;
}