//static member function
#include<iostream>
using namespace std;

class Maths
{
    public:
        static int sum(int n1,int n2)
        {
            return n1+n2;
        }
        static int minus(int n1,int n2)
        {
            return n1-n2;
        }
        int multiply(int n1,int n2)
        {
            return n1*n2;
        }
};
int main(void)
{
    int ans;
    ans= Maths::sum(10,20);
    cout<<"addition using className ="<<ans<<endl;

    ans= Maths::minus(10,20);
    cout<<"minus using className ="<<ans<<endl;

//    ans= Maths::multiply(10,20);
    Maths obj1;
    ans= obj1.sum(10,20);
    cout<<"addition using object Name ="<<ans<<endl;

    ans= obj1.minus(10,20);
    cout<<"minus using object Name ="<<ans<<endl;

    ans= obj1.multiply(10,20);
    cout<<"multiply using object Name ="<<ans<<endl;
    return 0;
}
// static member funtcion are designed to called on classname
// but it can be call on object name also

// non static member funtcion are designed to called on object name only
//not on class Name


