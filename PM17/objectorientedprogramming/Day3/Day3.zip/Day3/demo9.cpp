#include<iostream>
using namespace std;

class Friend_Demo
{
    private:
        int a;
        int b;
    public:
        Friend_Demo()
        {
            this->a=10;
            this->b=20;
        }
        Friend_Demo(int a, int b)
        {
            this->a=a;
            this->b=b;
        }

        ~Friend_Demo()
        {
            this->a=0;
            this->b=0;
        }
    friend void sum();

};
void sum()
{
    Friend_Demo obj1;
    int ans= obj1.a +obj1.b;
    cout<<"ans="<<ans<<endl;
    return ;
}
int main(void)
{
    sum();
    return 0;
}

