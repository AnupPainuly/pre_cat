/// way1 operator overloading using frined function
// global fun (c prog)

#include<iostream>
using namespace std;
class Complex
{
    private: // variable/ data member / field
        int real;
        int imag;
    public: // member function/ methods
        //1.1 input
        //void accept_input(Complex * const this)
        void accept_input()
        {
            cout<<"Enter real=";
            cin>>this->real;
            cout<<"Enter imag=";
            cin>>this->imag;
        }
        //1.2 output
        void display_output()
        {
            cout<<"this->real="<<this->real<<"\t["<<&this->real<<"]"<<endl;
            cout<<"this->imag="<<this->imag<<"\t["<<&this->imag<<"]"<<endl;
        }
        // 2.1  parameterless ctor or no argument ctor
        // Complex(Complex * const this)
        Complex()
        {
            this->real=10;
            this->imag=20;
 
        }
        // 2.2  parameterized ctor with one argrments
        // Complex(Complex * const this, int value)
        Complex(int value)
        {
            this->real=value;
            this->imag=value;
 
        }
      // 2.3  parameterized ctor with two argrments
      // Complex(Complex * const this, int real, int imag)
        Complex(int real, int imag)
        {
            this->real=real;
            this->imag=imag;
 
        }

        // 3. dtor
        ~Complex()
        {
            this->real=0;
            this->imag=0;
 
        }
    friend Complex sum(Complex other1, Complex other2);
    friend Complex operator+(Complex other1, Complex other2);

};
Complex sum(Complex other1, Complex other2)
{
    Complex temp;
    temp.real=other1.real+other2.real;
    temp.imag=other1.imag+other2.imag;
    return temp;
}
Complex operator+(Complex other1, Complex other2)
{
    Complex temp;
    temp.real=other1.real+other2.real;
    temp.imag=other1.imag+other2.imag;
    return temp;
}
int main()
{
    Complex c1(10,20), c2(30,40);
    cout<<"C1="<<endl;
    c1.display_output();  // 10 20
    cout<<"C2="<<endl;
    c2.display_output();  // 30 40

    Complex c3= sum(c1, c2);
    cout<<"C3="<<endl;
    c3.display_output();  // 40 60

    Complex c4= c1 + c2;
    //Complex c4= operator+(c1, c2);
    cout<<"C4="<<endl;
    c4.display_output();  // 40 60



    return 0;
}