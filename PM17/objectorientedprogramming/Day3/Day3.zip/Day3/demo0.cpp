day3
 // reference
  //swap using ref
  //dynamic memory allocation
  //exception handling
  static member fun & static data member
  friend demo
  operator overloading 
// template for function 
// template for class

