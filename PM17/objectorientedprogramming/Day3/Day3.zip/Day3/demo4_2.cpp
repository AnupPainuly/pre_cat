// call by value
#include<iostream>
using namespace  std;
// n1 , n2 are fromal arg
// n1 is refrerence of no1
// n2 is refrerence of no2
void swap(int &n1, int &n2)
{
    int temp;
    temp=n1;
    cout<<"before swap in swap n1="<<n1<<"\t n2="<<n2<<endl;    
    n1=n2;
    n2=temp;
    cout<<"after swap in swap n1="<<n1<<"\t n2="<<n2<<endl;    
    return;
}
int main(void)
{
    int no1=10, no2=20;
    cout<<"before swap in main no1="<<no1<<"\t no2="<<no2<<endl;    
    swap(no1, no2); // no1, no2 actual arg
    cout<<"after swap in main no1="<<no1<<"\t no2="<<no2<<endl;
    return 0;
}

